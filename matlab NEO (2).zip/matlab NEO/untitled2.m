% ==========================================
% DATA DEFINITIONS (NASA LSP & Arianespace)
% ==========================================

% Falcon Heavy
c3_fh = [-2, 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100];
mass_fh = [15500, 15000, 12300, 10100, 8200, 6600, 5200, 4100, 3100, 2200, 1400, 700];

% Vulcan Centaur (VC6L)
c3_vc6 = [-10, 0, 10, 20, 30, 40, 50, 60, 70, 80];
mass_vc6 = [12700, 10800, 9100, 7600, 6300, 5100, 4100, 3200, 2400, 1700];

% Ariane 64 (4 Boosters)
c3_a64 = [0, 10, 20, 30, 40, 50];
mass_a64 = [8500, 6400, 4700, 3200, 2000, 1000];

% Falcon 9
c3_f9 = [0, 10, 20, 30, 40, 50, 60];
mass_f9 = [5500, 4300, 3200, 2400, 1600, 900, 400];

% Ariane 62 (2 Boosters)
c3_a62 = [0, 10, 20, 30];
mass_a62 = [3500, 2400, 1500, 900];

% ==========================================
% GRAPH 1: C3 vs PAYLOAD (TECHNICAL DESIGN)
% ==========================================

fig1 = figure('Name', 'C3 vs Payload', 'Color', 'w', 'Position', [100, 100, 900, 600]);
hold on;

% Plot Lines with custom colors and markers
p1 = plot(c3_fh, mass_fh, '-bo', 'LineWidth', 1.2, 'MarkerSize', 4.5, 'MarkerFaceColor', 'b');
p2 = plot(c3_vc6, mass_vc6, '-o', 'Color', [0 1 0], 'LineWidth', 1.2, 'MarkerSize', 4.5, 'MarkerFaceColor', [0 1 0]);
p3 = plot(c3_a64, mass_a64, '-^', 'Color', [0.5 0 0.5], 'LineWidth', 1.2, 'MarkerSize', 5.5, 'MarkerFaceColor', [0.5 0 0.5]);
p4 = plot(c3_f9, mass_f9, '-s', 'Color', [1 0.55 0], 'LineWidth', 1.2, 'MarkerSize', 4.5, 'MarkerFaceColor', [1 0.55 0]);
p5 = plot(c3_a62, mass_a62, '-d', 'Color', [0.55 0.27 0.07], 'LineWidth', 1.2, 'MarkerSize', 5, 'MarkerFaceColor', [0.55 0.27 0.07]);

% Target Mass Marker segment (Black horizontal line)
plot([20, 25], [9812, 9812], 'k-', 'LineWidth', 2.5);

% Vertical Line at C3 = 25
xline(25, '-', '25', 'Color', [0.5 0.5 0.5], 'LineWidth', 1.2, ...
      'LabelHorizontalAlignment', 'center', 'LabelVerticalAlignment', 'bottom');

% Axes Limits & Formatting
xlim([-20, 120]);
ylim([0, 16000]);

ax1 = gca;
grid on;
ax1.GridLineStyle = '--';
ax1.GridAlpha = 0.7;
ax1.XTick = -20:20:120;
ax1.YTick = 0:2000:16000;
ax1.TickDir = 'in';       % Inward facing ticks
ax1.Box = 'on';           % Boxed outline like technical charts
ax1.LineWidth = 1;

% Labels and Legend
xlabel('C3 (km^2/sec^2)', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('Mass (kg)', 'FontSize', 12, 'FontWeight', 'bold');

lgd = legend([p1, p2, p3, p4, p5], {'Falcon Heavy', 'Vulcan (VC6L)', 'Ariane 64', 'Falcon 9', 'Ariane 62'}, ...
    'Location', 'northoutside', 'Orientation', 'horizontal', 'NumColumns', 3, 'FontSize', 10);
lgd.Box = 'on';

hold off;

% Save Graph 1
exportgraphics(fig1, 'C3_vs_Payload_Technical_MATLAB.png', 'Resolution', 300);

% ==========================================
% GRAPH 2: LAUNCH COST ESTIMATES
% ==========================================

fig2 = figure('Name', 'Launch Cost Estimates', 'Color', 'w', 'Position', [150, 150, 800, 500]);
    
vehicles = {'Falcon Heavy', sprintf('Vulcan\n(VC6L)'), 'Ariane 64', 'Falcon 9', 'Ariane 62'};
costs = [150, 130, 130, 76, 95];

% Custom RGB Colors mapping to the Python version
colors = [0 0.2 0.8;        % Blue (FH)
          0.17 0.63 0.17;   % Green (Vulcan)
          0.5 0 0.5;        % Purple (Ariane 64)
          1 0.55 0;         % Orange (Falcon 9)
          0.55 0.27 0.07];  % Brown (Ariane 62)

hold on;
for i = 1:length(costs)
    b = bar(i, costs(i), 0.6, 'EdgeColor', 'k', 'LineWidth', 1);
    b.FaceColor = colors(i, :);
    
    % Value labels on top of bars
    text(i, costs(i) + 4, sprintf('$%dM', costs(i)), 'HorizontalAlignment', 'center', ...
        'VerticalAlignment', 'bottom', 'FontSize', 11, 'FontWeight', 'bold');
end

% Formatting
ylabel('Estimated Launch Cost (Millions USD)', 'FontSize', 11, 'FontWeight', 'bold');
title('Mission Launch Cost Trade-Off', 'FontSize', 13, 'FontWeight', 'bold');

ylim([0, 180]);
ax2 = gca;
ax2.XTick = 1:5;
ax2.XTickLabel = vehicles;
ax2.TickDir = 'in';
ax2.YGrid = 'on';
ax2.GridLineStyle = '--';
ax2.GridAlpha = 0.5;

hold off;

% Save Graph 2
exportgraphics(fig2, 'Launch_Cost_Estimates_MATLAB.png', 'Resolution', 300);