%% FGKepler_dt  f-g propagation for elliptic orbits using time step Δt (seconds)
%
% Propagates a two-body orbit using Lagrange F & G coefficients as a
% function of elapsed time (Δt).
% Internally solves Kepler's equation to compute eccentric anomaly change.
%
% Inputs:
%   dt_sec : propagation time [s]
%   r0_vec : initial position [km] (1x3 or 3x1)
%   v0_vec : initial velocity [km/s] (1x3 or 3x1)
%   mu     : gravitational parameter [km^3/s^2]
%
% Outputs:
%   rf     : propagated position [km] (3x1)
%   out    : struct of intermediate values (a, n, M, dE, F, G, ...)

function [rf, out] = FGKepler_dt(dt_sec, r0_vec, v0_vec, mu)

    r0_vec = r0_vec(:);
    v0_vec = v0_vec(:);

    r0 = norm(r0_vec);
    v0 = norm(v0_vec);

    % ---- Semi-major axis from orbital energy (elliptic: a > 0) ----
    den = (2*mu/r0 - v0^2);
    a   = mu / den;

    if (a <= 0) || ~isfinite(a)
        error('FGKepler_dt:NonElliptic', ...
              'Non-elliptic orbit (a<=0 or invalid). F&G Δt form here assumes elliptic.');
    end

    % ---- Mean motion and mean anomaly change ----
    n = sqrt(mu / a^3);
    M = n * dt_sec;

    % ---- sigma0 term (lecture notation) ----
    sigma0 = dot(r0_vec, v0_vec) / sqrt(mu);

    % ---- Solve Kepler Δt form for ΔE using fzero ----
    % dE - (1 - r0/a) sin(dE) - (sigma0/sqrt(a)) (cos(dE)-1) - M = 0
    fun = @(dE) dE ...
        - (1 - r0/a) * sin(dE) ...
        - (sigma0/sqrt(a)) * (cos(dE) - 1) ...
        - M;

    % Start guess near M (good for small/moderate eccentricity)
    dE0 = M;

    try
        dE = fzero(fun, dE0);
    catch
        % Fallback: bracket a root around the guess (more robust for larger steps)
        span = pi;  % widen if needed
        dE = fzero(fun, [dE0 - span, dE0 + span]);
    end

    % ---- Lagrange coefficients (F,G) for Δt form ----
    F = 1 - (a/r0) * (1 - cos(dE));
    G = dt_sec + sqrt(a^3/mu) * (sin(dE) - dE);

    % ---- Propagate ----
    rf = F*r0_vec + G*v0_vec;

    % Optional outputs for debugging / reporting
    if nargout > 1
        out = struct();
        out.r0     = r0;
        out.v0     = v0;
        out.a      = a;
        out.n      = n;
        out.dM     = M;
        out.dE     = dE;
        out.sigma0 = sigma0;
        out.F      = F;
        out.G      = G;
    end
end