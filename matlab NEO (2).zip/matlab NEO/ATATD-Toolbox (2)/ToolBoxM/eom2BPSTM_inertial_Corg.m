function [dx] = eom2BPSTM_inertial(t,x,mu)
%Non-linear EoM for 2BP and State Transition Matrix
xx = x(1);
yy = x(2);
zz = x(3);
vx = x(4);
vy = x(5);
vz = x(6);

sidephi = 6; %phi is a matrix [sidephi x sidephi]
phi = reshape(x(7:end),6,6);

xx2yy2zz2 = xx^2 + yy^2 + zz^2;
d3 = xx2yy2zz2.^1.5;
d5 = xx2yy2zz2.^2.5;
mud3 = mu/d3;
mud5 = mu/d5;

Uxx = -mud3 + 3*xx^2*mud5;
Uyy = -mud3 + 3*yy^2*mud5;
Uzz = -mud3 + 3*zz^2*mud5;
Uxy = 3*xx*yy*mud5;
Uyx = Uxy;
Uxz = 3*xx*zz*mud5;
Uzx = Uxz;
Uyz = 3*yy*zz*mud5;
Uzy = Uyz;

A = [0 0 0 1 0 0;...
     0 0 0 0 1 0;...
     0 0 0 0 0 1;...
     Uxx Uxy Uxz 0 0 0;...
     Uyx Uyy Uyz 0 0 0;...
     Uzx Uzy Uzz 0 0 0];
    
dx = zeros(6,1);
dx(1) = vx;
dx(2) = vy;
dx(3) = vz;
dx(4) = -mud3*xx;
dx(5) = -mud3*yy; %
dx(6) = -mud3*zz;

dphi = A*phi;
dx = [dx; reshape(dphi,sidephi^2,1)];
end

