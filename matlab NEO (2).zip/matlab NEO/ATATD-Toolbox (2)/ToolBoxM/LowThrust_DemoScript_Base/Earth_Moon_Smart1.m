clear all; close all; clc; 
%% Earth-Moon Smart-1 Trajectory
% Smart-1 spacecraft (367 kg) is launched into a 250 km circular altitude
% orbit. Smart-1 propulsion system uses a Hall-effect Plasma Thruster with
% Isp of 3,000s and thruster efficiency of η=0.7. The input power is of 1190
% W. What would it be the total DV to reach Lunar altitude? And what the
% propellant mass used?
%% Compute how long you need to thrust for to reach escape velocity?
% Note: use equations in slide 10.

% Inputs
muEarth = 396800;
Isp  = 3000;       % Specific impulse (s)
n    = 0.7;        % Efficiency
P    = 1190;       % Input power
g0   = 9.81;       % Acceleration due to gravity (m/s^2)
m0   = 367;        % Initial mass (kg)
r0   = 6378 + 250; % Initial position (km)
rM   = 384400;     % Moon radius

% EP thrust-power equation
T = (2 * n * P) / (g0 * Isp);

% Orbital velocity & target ∆v
v_LEO     = sqrt(muEarth / r0);
v_Moon    = sqrt(muEarth / rM);
dv_target = abs(v_Moon - v_LEO) * 1000;

% Exhaust velocity
ve = Isp * g0; % Calculate exhaust velocity

% Mass flow rate
mdot = T / ve;

% Calculate final mass from rocket equation
m0_mf  = exp(dv_target / ve);
mf     = m0 / m0_mf;
m_prop = m0 - mf;

% Burn time from propellant consumption
t_burn = (m0 - mf) / mdot;   % seconds
t_hr   = t_burn / 3600;
t_day  = t_burn / 86400;

% print
fprintf('Thrust: %.2f N\n', T);
fprintf('Initial velocity (LEO): %.2f km/s\n', v_LEO);
fprintf('Target velocity (Moon): %.2f km/s\n', v_Moon);
fprintf('Delta V required: %.2f km/s\n', dv_target / 1000);
fprintf('Exhaust velocity: %.2f m/s\n', ve);
fprintf('Mass flow rate: %.6f kg/s\n', mdot);
fprintf('Final mass: %.2f kg\n', mf);
fprintf('Propellant mass used: %.2f kg\n', m_prop);
fprintf('Thrust time for escape velocity: %.2f seconds (%.2f hours, %.2f days)\n', t_burn, t_hr, t_day);

%% Low Thrust Propagation
% Use the above computed thrusting time DT, as propagation time for the ODE

% Initial orbit
SV0 = [r0; 0; 0; 0; v_LEO; 0; m0];

% LOW THRUST Controls
        % Tangential Thrust Vector (Same direction as velocity)
        Tx=@(t,x) (T*x(4)/sqrt(x(4)^2+x(5)^2+x(6)^2));
        Ty=@(t,x) (T*x(5)/sqrt(x(4)^2+x(5)^2+x(6)^2));
        Tz=@(t,x) (T*x(6)/sqrt(x(4)^2+x(5)^2+x(6)^2)); %T=Tmx*V/|V|

        %Equation of motion ¨r+mu*r/R^3 = T/m
        F=@(t,x)   [x(4); %dx/dt=Vx
                    x(5); %dy/dt=Vy
                    x(6); %dz/dt=Vz
                    -muEarth*x(1)/(sqrt(x(1)^2+x(2)^2+x(3)^2)^3)+Tx(t,x)/(x(7)*1000); %dVx/dt
                    -muEarth*x(2)/(sqrt(x(1)^2+x(2)^2+x(3)^2)^3)+Ty(t,x)/(x(7)*1000); %dVx/dt
                    -muEarth*x(3)/(sqrt(x(1)^2+x(2)^2+x(3)^2)^3)+Tz(t,x)/(x(7)*1000); %dVx/dt
                    -sqrt(Tx(t,x)^2 + Ty(t,x)^2 + Tz(t,x)^2)/ve]; %dm/dt=T/Isp;

        options = odeset('RelTol',1e-6,'AbsTol',1e-7,'Refine',50);
        
        %Propagation
        [tSol, X] = ode45(F,[0,t_burn],SV0,options);

%--------------------------------------------------------------------------
% Plot reference frame
run PlotEarth_Equatorial_frame.m
plot3(X(:,1),X(:,2),X(:,3))
view(0,90)