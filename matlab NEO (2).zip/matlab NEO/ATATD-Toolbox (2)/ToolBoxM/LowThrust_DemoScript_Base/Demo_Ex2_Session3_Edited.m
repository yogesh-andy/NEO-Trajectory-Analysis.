clear all; close all; clc; 
%% Demo_Ex2_Session3.m
% Propagate, using Matlab ODE solvers, the escape trajectory described in
% the previous exercise using a constant thrust in tangential direction.
% Initial Orbit: Circular 250 km altitude parking orbit. Apogee motor
% specs: Thrust 425 N,  Isp 320s. Spacecraft wet mass : 2000 kg.
%% Compute how long you need to thrust for to reach escape velocity?
% Note: use equations in slide 10.

% Inputs
muEarth = 396800;
T    = 425;   % Thrust (N)
Isp  = 320;        % Specific impulse (s)
g0   = 9.81;       % Acceleration due to gravity (m/s^2)
m0   = 2000;       % Initial mass (kg)
r0   = 6378 + 250; % Initial position (km)

% Orbital velocity & target v
LEO = sqrt(muEarth / r0);
Escape = sqrt((2 * muEarth) / r0);
Targetdv = (Escape - LEO) * 1000; % m/s

% Exhaust velocity
ve = Isp * g0; % Calculate exhaust velocity

% Mass flow rate
mdot = T / ve;

% Calculate final mass from rocket equation
m0_mf  = exp(Targetdv / ve);
mf     = m0 / m0_mf;
m_prop = m0 - mf;

% Calculate t for escape velocity
dt    = (m0 / mdot) * (1 - exp(-(Targetdv * mdot) / T));
dt_hr = dt / 3600;

% print dt and dt_hr
fprintf('Thrust time for escape velocity: %.2f seconds (%.2f hours)\n', dt, dt_hr);

%% Low Thrust Propagation
% Use the above computed thrusting time DT, as propagation time for the ODE

% Initial orbit
SV0 = [r0; 0; 0; 0; LEO; 0; m0];

% LOW THRUST Controls
        % Tangential Thrust Vector (Same direction as velocity)
        Tx=@(t,x) (T*x(4)/sqrt(x(4)^2+x(5)^2+x(6)^2));
        Ty=@(t,x) (T*x(5)/sqrt(x(4)^2+x(5)^2+x(6)^2));
        Tz=@(t,x) (T*x(6)/sqrt(x(4)^2+x(5)^2+x(6)^2)); %T=Tmx*V/|V|

        %Equation of motion �r+mu*r/R^3 = T/m
        F=@(t,x)   [x(4); %dx/dt=Vx
                    x(5); %dy/dt=Vy
                    x(6); %dz/dt=Vz
                    -muEarth*x(1)/(sqrt(x(1)^2+x(2)^2+x(3)^2)^3)+Tx(t,x)/(x(7)*1000); %dVx/dt
                    -muEarth*x(2)/(sqrt(x(1)^2+x(2)^2+x(3)^2)^3)+Ty(t,x)/(x(7)*1000); %dVx/dt
                    -muEarth*x(3)/(sqrt(x(1)^2+x(2)^2+x(3)^2)^3)+Tz(t,x)/(x(7)*1000); %dVx/dt
                    -sqrt(Tx(t,x)^2 + Ty(t,x)^2 + Tz(t,x)^2)/ve]; %dm/dt=T/Isp;

        options = odeset('RelTol',1e-6,'AbsTol',1e-7,'Refine',50);
        
        %Propagation
        [tSol, X] = ode45(F,[0,dt],SV0,options);

%--------------------------------------------------------------------------
% Plot reference frame
run PlotEarth_Equatorial_frame.m
plot3(X(:,1),X(:,2),X(:,3))
view(0,90)

%% Did we reach escape velocity?
% A spacecraft will be in a escape trajectory if at any given altitude it
% has a velocity equivalent to sqrt(2*muEarth/r);
% Hence, let's check the final velocity of the above propagation.

SV_final = X(end, :);     % final state vector
rf       = sqrt(SV_final(1)^2 + SV_final(2)^2 + SV_final(3)^2);   % final distance to earth
v_esc    = sqrt(2 * muEarth / rf);
vf       = sqrt(SV_final(4)^2 + SV_final(5)^2 + SV_final(6)^2);

% check
fprintf('\n================ Initial Duration (dt = %.2f s) =================\n', dt_hr);
if vf >= v_esc
    fprintf('Escape achieved\n');
else
    fprintf('Still bound to Earth.\n');
end

%% Propagate the trajectory until reaching escape conditions
% Use MATLAB�s ODE event feature to stop the propagation when it reaches
% escape velocity. For information on how to do this go to:
% https://uk.mathworks.com/help/matlab/math/ode-event-location.html


% Spacecraft in circular orbit 250 km
% RE - radius of the Earth
% Vc - velocity circular orbit
% Msc- spacecraft mass
SV0 = [r0; 0; 0; 0; LEO; 0; m0];
tf=10*dt; % make sure you propagate for substantially longer than the 
          % previous propagation time

% LOW THRUST Controls
        % Tangential Thrust Vector (Same direction as velocity)
        Tx=@(t,x) (T*x(4)/sqrt(x(4)^2+x(5)^2+x(6)^2));
        Ty=@(t,x) (T*x(5)/sqrt(x(4)^2+x(5)^2+x(6)^2));
        Tz=@(t,x) (T*x(6)/sqrt(x(4)^2+x(5)^2+x(6)^2)); %T=Tmx*V/|V|

        %Equation of motion �r+mu*r/R^3 = T/m
        F=@(t,x)   [x(4); %dx/dt=Vx
                    x(5); %dy/dt=Vy
                    x(6); %dz/dt=Vz
                    -muEarth*x(1)/(sqrt(x(1)^2+x(2)^2+x(3)^2)^3)+Tx(t,x)/(x(7)*1000); %dVx/dt
                    -muEarth*x(2)/(sqrt(x(1)^2+x(2)^2+x(3)^2)^3)+Ty(t,x)/(x(7)*1000); %dVx/dt
                    -muEarth*x(3)/(sqrt(x(1)^2+x(2)^2+x(3)^2)^3)+Tz(t,x)/(x(7)*1000); %dVx/dt
                    -sqrt(Tx(t,x)^2 + Ty(t,x)^2 + Tz(t,x)^2)/ve]; %dm/dt=T/Isp;
             
        
        options=odeset('RelTol',1e-6,'AbsTol',1e-7,'Refine',50,'Events',@(t,x)event_Escape(t,x));
        % event_Escape is defined as in slide 21
        
        %Propagation
        [T,X,TE,YE,IE]=ode45(F,[0,tf],SV0,options);

%--------------------------------------------------------------------------
% Plot reference frame
run PlotEarth_Equatorial_frame.m
plot3(X(:,1),X(:,2),X(:,3))
view(0,90)

%% --------------------------------------------------------------------------
% Is the final state vector in a escape trajectory? 

SV_final = X(end, :);     % final state vector
rf       = sqrt(SV_final(1)^2 + SV_final(2)^2 + SV_final(3)^2);   % final distance to earth
v_esc    = sqrt(2 * muEarth / rf);
vf       = sqrt(SV_final(4)^2 + SV_final(5)^2 + SV_final(6)^2);

% check
fprintf('\n================ Event-based propagation =================\n');
if ~isempty(TE)
    fprintf('Escape achieved at TE = %.2f s (%.2f hr)\n', TE(end), TE(end)/3600);
else
    fprintf('Still bound to Earth after tf = %.2f s (%.2f hr)\n', tf, tf/3600);
end

%% --------------------------------------------------------------------------
% What is the gravity loss that we will have if we intent to thrust until
% escape velocity from parking orbit with our engine?

% the total thrust time is TE

% calculate difference between v from rocket equation and v for TE
mf2     = m0 - (mdot * TE);
m_prop2 = m0 - mf2;
dv_real = ve * log(m0 / mf2);
g_loss  = Targetdv - dv_real;

% print mf2, m_prop2, dv_real, g_loss
fprintf('\n================ Gravity Losses =================\n');
fprintf('Final mass after escape: mf2 = %.2f kg\n', mf2);
fprintf('Propellant mass used: m_prop2 = %.2f kg\n', m_prop2);
fprintf('Real delta-v achieved: dv_real = %.2f m/s\n', dv_real);
fprintf('Gravity loss: g_loss = %.2f m/s\n', g_loss);

%% Exercise Slide 40 - Low Thrust Transfer Design %%
% A cluster of three Hall-effect thrusters produces 0.6 N of total thrust. Each hall thruster
% has an Isp of 1700 s. Compute the low-thrust transfer time and propellant mass for a
% coplanar transfer from LEO to GEO. The parking LEO altitude shall be 300 km and the
% initial mass for the spacecraft 2500 kg.

% Define parameters for the low-thrust transfer
Isp_2        = 1700;         % specific impulse in seconds
T_2          = 0.6;          % total thrust in Newtons
m0_2         = 2500;         % initial mass of the spacecraft in kg
H_LEO        = 300;          % altitude of LEO in km
H_GEO        = 35786;        % altitude of GEO in km
r_LEO        = 6378 + H_LEO; % radius of LEO in km
r_GEO        = 6378 + H_GEO; % radius of GEO in km

% Orbital velocity & target v
v_LEO      = sqrt(muEarth / r_LEO);
v_GEO      = sqrt(muEarth / r_GEO);
Targetdv_2 = abs((v_GEO - v_LEO) * 1000); % m/s

% Exhaust velocity
ve_2 = Isp_2 * g0; % Calculate exhaust velocity

% Mass flow rate
mdot_2 = T_2 / ve_2;

% Calculate final mass from rocket equation
m0_mf_2  = exp(Targetdv_2 / ve_2);
mf_2     = m0_2 / m0_mf_2;
m_prop_2 = m0_2 - mf_2;

% Calculate t for escape velocity
dt_sec_2    = (m0_2 / mdot_2) * (1 - exp(-(Targetdv_2 * mdot_2) / T_2));
dt_hr_2     = dt_sec_2 / 3600;
dt_day      = dt_hr_2 / 24;

% print Targetdv_2, ve_2, mdot_2, mf_2, dt_sec_2 and dt_hr_2
fprintf('Target delta-v for transfer: Targetdv_2 = %.2f m/s\n', Targetdv_2);
fprintf('Exhaust velocity: ve_2 = %.2f m/s\n', ve_2);
fprintf('Mass flow rate: mdot_2 = %.6f kg/s\n', mdot_2);
fprintf('Final mass after transfer: mf_2 = %.2f kg\n', mf_2);
fprintf('Propellant mass used: m_prop_2 = %.2f kg\n', m_prop_2);
fprintf('Time for transfer: dt_sec_2 = %.2f s (%.2f hr)\n', dt_sec_2, dt_hr_2);
fprintf('Time for transfer: dt_day = %.2f days\n', dt_day);

%% Low Thrust Propagation Slide 40 %%
% Use the above computed thrusting time DT, as propagation time for the ODE

% Initial orbit
SV0_2 = [r_LEO; 0; 0; 0; v_LEO; 0; m0_2];

% LOW THRUST Controls
        % Tangential Thrust Vector (Same direction as velocity)
        Tx=@(t,x) (T_2*x(4)/sqrt(x(4)^2+x(5)^2+x(6)^2));
        Ty=@(t,x) (T_2*x(5)/sqrt(x(4)^2+x(5)^2+x(6)^2));
        Tz=@(t,x) (T_2*x(6)/sqrt(x(4)^2+x(5)^2+x(6)^2)); %T=Tmx*V/|V|

        %Equation of motion �r+mu*r/R^3 = T/m
        F=@(t,x)   [x(4); %dx/dt=Vx
                    x(5); %dy/dt=Vy
                    x(6); %dz/dt=Vz
                    -muEarth*x(1)/(sqrt(x(1)^2+x(2)^2+x(3)^2)^3)+Tx(t,x)/(x(7)*1000); %dVx/dt
                    -muEarth*x(2)/(sqrt(x(1)^2+x(2)^2+x(3)^2)^3)+Ty(t,x)/(x(7)*1000); %dVx/dt
                    -muEarth*x(3)/(sqrt(x(1)^2+x(2)^2+x(3)^2)^3)+Tz(t,x)/(x(7)*1000); %dVx/dt
                    -sqrt(Tx(t,x)^2 + Ty(t,x)^2 + Tz(t,x)^2)/ve_2]; %dm/dt=T/Isp;

        options = odeset('RelTol',1e-6,'AbsTol',1e-7,'Refine',50);
        
        %Propagation
        [tSol_2, X] = ode45(F,[0,dt_sec_2],SV0_2,options);

%--------------------------------------------------------------------------
% Plot reference frame
run PlotEarth_Equatorial_frame.m
plot3(X(:,1),X(:,2),X(:,3))
view(0,90)

%% ---- Final state
SVf = X(end,:).';
r   = SVf(1:3);          % km
v   = SVf(4:6);          % km/s

rf = norm(r);
vf = norm(v);

% ---- GEO target radius
rGEO = H_GEO;            % km (you already set H_GEO = 6378 + 35786)

% ---- Specific orbital energy and semi-major axis
eps  = 0.5*vf^2 - muEarth/rf;      % km^2/s^2
a    = -muEarth/(2*eps);           % km  (valid if bound)

% ---- Angular momentum and eccentricity vector
hvec = cross(r,v);                 % km^2/s
evec = (cross(v,hvec)/muEarth) - (r/rf);
e    = norm(evec);

% ---- Period (if bound)
Torb = 2*pi*sqrt(a^3/muEarth);     % s

% ---- Print checks
fprintf('\n==== GEO check (final state) ====\n');
fprintf('Final radius rf         = %.2f km (target %.2f km)\n', rf, rGEO);
fprintf('Semi-major axis a       = %.2f km (target %.2f km)\n', a,  rGEO);
fprintf('Eccentricity e          = %.6f (target ~0)\n', e);
fprintf('Orbital period          = %.2f hr (target ~23.93 hr)\n', Torb/3600);

% ---- Simple pass/fail thresholds (tweak as you like)
tol_a = 50;          % km
tol_e = 1e-3;        % -
if abs(a - rGEO) < tol_a && e < tol_e
    fprintf(' Reached near-GEO (a and e within tolerance)\n');
else
    fprintf(' Not GEO yet (check a/e)\n');
end

%% Propagate the trajectory until reaching GEO %%
% Use MATLAB�s ODE event feature to stop the propagation when it reaches
% GEO. For information on how to do this go to:
% https://uk.mathworks.com/help/matlab/math/ode-event-location.html


% Spacecraft in circular orbit 250 km
% RE - radius of the Earth
% Vc - velocity circular orbit
% Msc- spacecraft mass
SV0 = [r_LEO; 0; 0; 0; v_LEO; 0; m0_2];
tf_2  = 5 * dt_sec_2; % make sure you propagate for substantially longer than the 
          % previous propagation time

% LOW THRUST Controls
        % Tangential Thrust Vector (Same direction as velocity)
        Tx=@(t,x) (T_2*x(4)/sqrt(x(4)^2+x(5)^2+x(6)^2));
        Ty=@(t,x) (T_2*x(5)/sqrt(x(4)^2+x(5)^2+x(6)^2));
        Tz=@(t,x) (T_2*x(6)/sqrt(x(4)^2+x(5)^2+x(6)^2)); %T=Tmx*V/|V|

        %Equation of motion �r+mu*r/R^3 = T/m
        F=@(t,x)   [x(4); %dx/dt=Vx
                    x(5); %dy/dt=Vy
                    x(6); %dz/dt=Vz
                    -muEarth*x(1)/(sqrt(x(1)^2+x(2)^2+x(3)^2)^3)+Tx(t,x)/(x(7)*1000); %dVx/dt
                    -muEarth*x(2)/(sqrt(x(1)^2+x(2)^2+x(3)^2)^3)+Ty(t,x)/(x(7)*1000); %dVx/dt
                    -muEarth*x(3)/(sqrt(x(1)^2+x(2)^2+x(3)^2)^3)+Tz(t,x)/(x(7)*1000); %dVx/dt
                    -sqrt(Tx(t,x)^2 + Ty(t,x)^2 + Tz(t,x)^2)/ve_2]; %dm/dt=T/Isp;
             
        
        options=odeset('RelTol',1e-6,'AbsTol',1e-7,'Refine',50,'Events',@(t,x)event_GEO_a(t,x, muEarth, H_GEO));
        % event_Escape is defined as in slide 21
        
        %Propagation
        [T2,X2,TE2,YE2,IE2]=ode45(F,[0,tf_2],SV0_2,options);

function [value, isterminal, direction] = event_GEO_a(~,x,muEarth,aGEO)
    r = x(1:3); v = x(4:6);
    rnorm = norm(r); vnorm = norm(v);

    eps = 0.5*vnorm^2 - muEarth/rnorm;   % km^2/s^2
    a   = -muEarth/(2*eps);              % km

    value = a - aGEO;     % trigger when a = aGEO
    isterminal = 1;       % stop integration
    direction  = +1;      % only trigger when a is increasing through aGEO
end

%--------------------------------------------------------------------------
% Plot reference frame
run PlotEarth_Equatorial_frame.m
plot3(X(:,1),X(:,2),X(:,3))
view(0,90)