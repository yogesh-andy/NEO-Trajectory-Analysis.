%% CR3BP - Zero Velocity Curves (L1, L2, L3) %%
% Steps (Slides 28-29 idea):
% 1) Solve L1/L2/L3 (x,0,0) using collinear equilibrium equation
% 2) Compute C(Li) = 2*U(Li) (since v=0 at equilibrium points)
% 3) Build grid and compute v^2(x,y,z) = 2U - C(Li)
% 4) Plot z=0 zero-velocity curves (overlay + separate)
% 5) Optional: plot 3D isosurfaces (overlay + separate)
%--------------------------------------------------------------------------
clear; clc; close all;
%--------------------------------------------------------------------------

%% Constants and definitions for Earth-Moon System
massEarth = getAstroConstants('Earth','mass');
massMoon  = getAstroConstants('Moon','mass');
mu        = massMoon/(massMoon+massEarth);   % CR3BP mass parameter

% Primaries in barycentric rotating frame
x1 = -mu;        % Earth
x2 = 1 - mu;     % Moon

%% --- Collinear equilibrium condition (works for L1, L2, L3)
fCol = @(x) x ...
    - (1-mu) * (x - x1) ./ abs(x - x1).^3 ...
    - (mu)   * (x - x2) ./ abs(x - x2).^3;

opts = optimset('TolX',1e-14,'Display','off');

% --- Solve L1/L2/L3
xL1 = fzero(fCol, (x1 + x2)/2, opts);   % between primaries
xL2 = fzero(fCol, x2 + 0.2, opts);      % right of Moon
xL3 = fzero(fCol, x1 - 1.2, opts);      % left of Earth

fprintf('mu = %.12f\n', mu);
fprintf('L1 x = %.15f\nL2 x = %.15f\nL3 x = %.15f\n', xL1, xL2, xL3);

%% --- Helper: U(x,y,z) and C at equilibrium
Ufun = @(x,y,z) 0.5*(x.^2 + y.^2) ...
    + (1-mu)./sqrt((x - x1).^2 + y.^2 + z.^2) ...
    + (mu)  ./sqrt((x - x2).^2 + y.^2 + z.^2);

% At Li, y=z=0, v=0 => C(Li) = 2U(Li)
U_L1 = Ufun(xL1,0,0);  C_L1 = 2*U_L1;
U_L2 = Ufun(xL2,0,0);  C_L2 = 2*U_L2;
U_L3 = Ufun(xL3,0,0);  C_L3 = 2*U_L3;

fprintf('\nU(L1)=%.15f  C(L1)=%.15f\n', U_L1, C_L1);
fprintf('U(L2)=%.15f  C(L2)=%.15f\n', U_L2, C_L2);
fprintf('U(L3)=%.15f  C(L3)=%.15f\n', U_L3, C_L3);

%% --- Compute v^2 on a 3D grid (in x,y,z)
Nx = 200; Ny = 200; Nz = 120;

xMin = -2.2; xMax =  2.2;
yMin = -2.2; yMax =  2.2;
zMin = -1.2; zMax =  1.2;

[xg, yg, zg] = meshgrid(linspace(xMin, xMax, Nx), ...
                        linspace(yMin, yMax, Ny), ...
                        linspace(zMin, zMax, Nz));

% Potential U over grid (elementwise!)
U = Ufun(xg, yg, zg);

% v^2 fields for each C level
v2_L1 = 2*U - C_L1;
v2_L2 = 2*U - C_L2;
v2_L3 = 2*U - C_L3;

% Slice index closest to z=0 (for ZVCs)
[~, k0] = min(abs(linspace(zMin,zMax,Nz)));

X0 = xg(:,:,k0);
Y0 = yg(:,:,k0);
V2_L1_0 = v2_L1(:,:,k0);
V2_L2_0 = v2_L2(:,:,k0);
V2_L3_0 = v2_L3(:,:,k0);

%% Sanity check: v^2 = 2U - C
v2_nearEarth = 2*Ufun(x1 + 0.02, 0, 0) - C_L1;   % close to Earth
v2_far       = 2*Ufun( 1.20, 1.20, 0) - C_L1;    % far away

fprintf('L1: v2 near Earth = %+ .3e (allowed if >=0)\n', v2_nearEarth);
fprintf('L1: v2 far away   = %+ .3e (allowed if >=0)\n', v2_far);

%% ===========================
% PLOTS (LECTURE STYLE):
%  - z=0 slice: forbidden region filled solid grey + ZVC(s) in blue
%  - 3D isosurface unchanged
% Outputs:
%   (A) One 3x2 tiled figure (rows = L1/L2/L3; cols = slice / isosurface)
%   (B) Six individual figures (same content, one per panel)
%
% Requirements in workspace BEFORE this section:
%   x1, x2, xL1,xL2,xL3, C_L1,C_L2,C_L3
%   Ufun(x,y,z)  (effective potential Omega/U)  OR xg,yg,zg,U already computed
%   xg,yg,zg, Nz, zMin,zMax
%   v2_L1,v2_L2,v2_L3 (or compute here from U)
% ===========================

% --- Colours (match lecture: ZVC in blue)
zvcColor = [0 0 1];
earthCol = [0 0 0];
moonCol  = [0.5 0.5 0.5];
greyFill = [0.65 0.65 0.65];

% --- Ensure v2 fields exist for 3D (uncomment if needed)
% v2_L1 = 2*U - C_L1;
% v2_L2 = 2*U - C_L2;
% v2_L3 = 2*U - C_L3;

% --- z=0 slice index for 3D grid (used only for 3D plots + k0 definition)
[~, k0] = min(abs(linspace(zMin, zMax, Nz)));

% --- IMPORTANT: make 2D domain big enough so outer ZVC is not clipped
% (This is the main reason your outer boundary was missing)
Nx2 = 600; Ny2 = 600;
xMin2 = -2.2; xMax2 =  2.2;
yMin2 = -2.2; yMax2 =  2.2;

[x2d, y2d] = meshgrid(linspace(xMin2,xMax2,Nx2), linspace(yMin2,yMax2,Ny2));

% --- Compute v^2 on z=0 plane for each C
% Prefer Ufun if available (recommended). Otherwise, fall back to computing from primaries.
if exist('Ufun','var') == 1 || exist('Ufun','file') == 2
    U2 = Ufun(x2d, y2d, 0);
else
    % Fallback (if you don't have Ufun): compute U = 0.5(x^2+y^2) + (1-mu)/r1 + mu/r2
    % Requires mu in workspace.
    if ~exist('mu','var'); error('mu not found and Ufun not available.'); end
    r1 = sqrt((x2d - x1).^2 + y2d.^2);
    r2 = sqrt((x2d - x2).^2 + y2d.^2);
    U2 = 0.5*(x2d.^2 + y2d.^2) + (1-mu)./r1 + mu./r2;
end

v2_2d_L1 = 2*U2 - C_L1;
v2_2d_L2 = 2*U2 - C_L2;
v2_2d_L3 = 2*U2 - C_L3;

%% ==========================================================
% (A) Single 3x2 tiled figure
% ==========================================================
figure('Color','w');
tiledlayout(3,2,'TileSpacing','compact','Padding','compact');

local_plot_row_tiled_lecture(v2_2d_L1, C_L1, xL1, 'L1', ...
    x2d, y2d, zvcColor, greyFill, earthCol, moonCol, x1, x2, ...
    v2_L1, xg, yg, zg);

local_plot_row_tiled_lecture(v2_2d_L2, C_L2, xL2, 'L2', ...
    x2d, y2d, zvcColor, greyFill, earthCol, moonCol, x1, x2, ...
    v2_L2, xg, yg, zg);

local_plot_row_tiled_lecture(v2_2d_L3, C_L3, xL3, 'L3', ...
    x2d, y2d, zvcColor, greyFill, earthCol, moonCol, x1, x2, ...
    v2_L3, xg, yg, zg);

%% ==========================================================
% (B) Six individual figures (for detailed inspection)
% ==========================================================
local_plot_slice_single_lecture(v2_2d_L1, C_L1, xL1, 'L1', x2d, y2d, zvcColor, greyFill, earthCol, moonCol, x1, x2);
local_plot_iso_single(v2_L1, C_L1, xL1, zvcColor, 'L1', xg, yg, zg, x1, x2);

local_plot_slice_single_lecture(v2_2d_L2, C_L2, xL2, 'L2', x2d, y2d, zvcColor, greyFill, earthCol, moonCol, x1, x2);
local_plot_iso_single(v2_L2, C_L2, xL2, zvcColor, 'L2', xg, yg, zg, x1, x2);

local_plot_slice_single_lecture(v2_2d_L3, C_L3, xL3, 'L3', x2d, y2d, zvcColor, greyFill, earthCol, moonCol, x1, x2);
local_plot_iso_single(v2_L3, C_L3, xL3, zvcColor, 'L3', xg, yg, zg, x1, x2);

%% ===========================
% Local functions (place at end of your script)
% ===========================

function local_plot_row_tiled_lecture(v2_2d, Cval, xL, tag, ...
    x2d, y2d, zvcColor, greyFill, earthCol, moonCol, x1, x2, ...
    v2_3d, xg, yg, zg)

    % ---- LEFT: z=0 lecture-style forbidden fill + ZVC(s)
    nexttile; hold on; axis equal; grid on; box on;

    forbidden = (v2_2d < 0);

    % Fill ONLY forbidden region (solid grey, like slides)
    contourf(x2d, y2d, double(forbidden), [0.5 0.5], ...
        'LineColor','none', 'FaceColor', greyFill);

    % Plot all ZVC components in domain (inner + outer)
    contour(x2d, y2d, v2_2d, [0 0], 'LineWidth', 2.5, 'LineColor', zvcColor);

    % Primaries + L point
    plot(x1,0,'.','Color',earthCol,'MarkerSize',22);
    plot(x2,0,'.','Color',moonCol, 'MarkerSize',18);
    plot(xL,0,'.','Color',zvcColor,'MarkerSize',24);

    xlabel('x (ND)'); ylabel('y (ND)');
    title(sprintf('%s: ZVC (z=0), C=%.6f', tag, Cval), 'Interpreter','none');

    xlim([min(x2d(:)) max(x2d(:))]);
    ylim([min(y2d(:)) max(y2d(:))]);

    % Simple legend key (avoid contour handle issues)
    plot(nan,nan,'-','Color',zvcColor,'LineWidth',2.5);
    plot(nan,nan,'s','MarkerFaceColor',greyFill,'MarkerEdgeColor','none','MarkerSize',10);
    plot(nan,nan,'.','Color',earthCol,'MarkerSize',22);
    plot(nan,nan,'.','Color',moonCol,'MarkerSize',18);
    plot(nan,nan,'.','Color',zvcColor,'MarkerSize',24);

    legend({'','','','ZVC (v^2=0)','Forbidden (v^2<0)','Earth','Moon',tag}, ...
        'Location','bestoutside');

    % ---- RIGHT: 3D isosurface v^2=0 (unchanged)
    nexttile; hold on; grid on; axis equal;

    p = patch(isosurface(xg, yg, zg, v2_3d, 0));
    isonormals(xg, yg, zg, v2_3d, p);
    set(p, 'FaceAlpha', 0.25, 'EdgeColor', 'none');

    plot3(x1,0,0,'ko','MarkerFaceColor','k','MarkerSize',6);
    plot3(x2,0,0,'ko','MarkerFaceColor',[0.6 0.6 0.6],'MarkerSize',5);
    plot3(xL,0,0,'.','Color',zvcColor,'MarkerSize',22);

    xlabel('x (ND)'); ylabel('y (ND)'); zlabel('z (ND)');
    title(sprintf('%s: 3D isosurface (v^2=0)', tag), 'Interpreter','none');

    view(35,20);
    camlight headlight; lighting gouraud;
end

function local_plot_slice_single_lecture(v2_2d, Cval, xL, tag, ...
    x2d, y2d, zvcColor, greyFill, earthCol, moonCol, x1, x2)

    figure('Color','w'); hold on; axis equal; grid on; box on;

    forbidden = (v2_2d < 0);

    contourf(x2d, y2d, double(forbidden), [0.5 0.5], ...
        'LineColor','none', 'FaceColor', greyFill);

    contour(x2d, y2d, v2_2d, [0 0], 'LineWidth', 2.5, 'LineColor', zvcColor);

    plot(x1,0,'.','Color',earthCol,'MarkerSize',22);
    plot(x2,0,'.','Color',moonCol, 'MarkerSize',18);
    plot(xL,0,'.','Color',zvcColor,'MarkerSize',24);

    xlabel('x (ND)'); ylabel('y (ND)');
    title(sprintf('%s: ZVC (z=0), C=%.10f', tag, Cval), 'Interpreter','none');

    xlim([min(x2d(:)) max(x2d(:))]);
    ylim([min(y2d(:)) max(y2d(:))]);

    plot(nan,nan,'-','Color',zvcColor,'LineWidth',2.5);
    plot(nan,nan,'s','MarkerFaceColor',greyFill,'MarkerEdgeColor','none','MarkerSize',10);
    plot(nan,nan,'.','Color',earthCol,'MarkerSize',22);
    plot(nan,nan,'.','Color',moonCol,'MarkerSize',18);
    plot(nan,nan,'.','Color',zvcColor,'MarkerSize',24);

    legend({'','','','ZVC (v^2=0)','Forbidden (v^2<0)','Earth','Moon',tag}, ...
        'Location','bestoutside');
end

function local_plot_iso_single(v2field, Cval, Lx, zvcColor, tag, ...
    xg, yg, zg, x1, x2)

    figure('Color','w'); hold on; grid on; axis equal;

    p = patch(isosurface(xg, yg, zg, v2field, 0));
    isonormals(xg, yg, zg, v2field, p);
    set(p, 'FaceAlpha', 0.30, 'EdgeColor', 'none');

    plot3(x1,0,0,'ko','MarkerFaceColor','k','MarkerSize',7);
    plot3(x2,0,0,'ko','MarkerFaceColor',[0.6 0.6 0.6],'MarkerSize',6);
    plot3(Lx,0,0,'.','Color',zvcColor,'MarkerSize',26);

    xlabel('x (ND)'); ylabel('y (ND)'); zlabel('z (ND)');
    title(sprintf('%s: 3D isosurface (v^2=0),  C=%.10f', tag, Cval), 'Interpreter','none');

    view(35,20);
    camlight headlight; lighting gouraud;
end
