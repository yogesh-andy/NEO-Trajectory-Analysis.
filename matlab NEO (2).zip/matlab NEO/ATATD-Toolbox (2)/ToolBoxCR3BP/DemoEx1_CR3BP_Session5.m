%% DemoEx1_CR3BP_Session4.m
% NOTES:
% This exercise allows comparing the shape of an elliptic orbit in both the
% inertial reference frame and the rotating reference frame.
% 1. Run each of the sections:
%    Click on each section in order and click Ctrl+Enter to run
%% PART 0. Set up
%--------------------------------------------------------------------------
clear all; clc; % close all
%--------------------------------------------------------------------------
% 1.1 Constants and definitions for Earth Moon System
massEarth   = getAstroConstants('Earth','mass');
muEarth   = getAstroConstants('Earth','mu');
massMoon = getAstroConstants('Moon','mass');
mu = massMoon/(massMoon+massEarth);
G = astroConstants(1);
EarthMoonDistance=379700; % km
RAD = pi/180;
RE = getAstroConstants('Earth','Radius');
%--------------------------------------------------------------------------
%% PART 1. Define orbit and plot in inertial reference frame 
%--------------------------------------------------------------------------
% Plot the frame
UnitDistance=EarthMoonDistance;
run PlotEarthMoon_system_Inertialframe.m
%--------------------------------------------------------------------------
% Define a Keplerian Orbit
% rp = 0.849; % periapsis distance (in Earth_Moon distance units)
% ra = 0.849; % apoapsos distance (in Earth_Moon distance units)

% rp = 1.168; % periapsis distance (in Earth_Moon distance units)
% ra = 1.168; % apoapsos distance (in Earth_Moon distance units)

rp = 0.993; % periapsis distance (in Earth_Moon distance units)
ra = 0.993; % apoapsos distance (in Earth_Moon distance units)

sma = (rp+ra)/2;       % semimajor axis
ecc = (ra-rp)/(rp+ra); % eccentricity 
inc = 0;  % inclination (rad)
OM0 = 0;  % RAAN (rad)
om  = pi; % Argument of the periapsis (rad)
trA = 0;  % true anomaly (rad)
%--------------------------------------------------------------------------
% Propagate Keplerian Orbit
% x.1. Compute cartesian inertial state vector
KepAsteroid = [sma ecc inc OM0 om trA];
PAst=2*pi*sqrt(sma^3/(1-mu));
SV = kep2car(KepAsteroid,1-mu);
% x.2 Propagate orbit
TSPAN = [0 10 * PAst];
OPTIONS = odeset('RelTol',3e-10,'AbsTol',1e-12);  % lower accuracy
MODEL = @dyn_2BP;
[t,Xinert]     = ode45(MODEL,TSPAN,SV,OPTIONS,1-mu);
%--------------------------------------------------------------------------
% Plot Keplerian Orbit
  plot3(Xinert(:,1),Xinert(:,2),Xinert(:,3))
%% PART 2. Plot same orbit in rotating reference frame 
%--------------------------------------------------------------------------
% Plot the frame
run PlotEarthMoon_system_frame.m
%--------------------------------------------------------------------------
% x.2. Normalize units to CR3BP
X=SV(1:3);
V=SV(4:6);
% x.3. Is a rotation necessary? no because at t=0, both Earth and asteroid
% are at trA=0
% x.4. Account for the mu translation of the center
X=[X(1)-mu X(2) X(3)]; % moved to the baricentre
V=[V(1) V(2)-mu V(3)];
% x.5. Rotating Reference frame
X=[X(1) X(2) X(3)];
V=[V(1)+X(2) V(2)-X(1) V(3)];
%--------------------------------------------------------------------------
% Propagate in CR3BP 3D
OPTIONS = odeset('RelTol',3e-10,'AbsTol',1e-12);

TintR = [0 4*PAst];
[SV_forward,t_forward] = trajGet3BP_3D([X V],0,TintR(2),mu,OPTIONS);
%--------------------------------------------------------------------------
plot3(SV_forward(:,1),SV_forward(:,2),SV_forward(:,3))

%% Exercise 2A - Earth-Moon Collinear Equilibrium Points %%

x1 = -mu;
x2 = 1 - mu;

% define robust function
%fun = @(x) x ...
   % - (1 - mu) * (x - x1) / abs(x - x1)^3 ...
   % - mu       * (x - x2) / abs(x - x2)^3;

% define L1-3 functions from slides
fL1 = @(x) x ...
    - (1 - mu) / (x - x1)^2 ...
    + mu / (x - x2)^2;

fL2 = @(x) x ...
    - (1 - mu) / (x - x1)^2 ...
    - mu / (x - x2)^2;

fL3 = @(x) x ...
    + (1 - mu) / (x - x1)^2 ...
    + mu / (x - x2)^2;

% fzero function to solve
L1 = fzero(fL1, (x1 + x2) / 2);     % mid-point between Earth-Moon
L2 = fzero(fL2, x2 + 0.2);          % right of Moon
L3 = fzero(fL3, x1 - 1.2);          % left of Earth

%print
fprintf('\n=== Collinear Lagrange points (non-dimensional x) ===\n');
fprintf('L1: x = %.10f\n', L1);
fprintf('L2: x = %.10f\n', L2);
fprintf('L3: x = %.10f\n', L3);

fprintf('\n=== Collinear Lagrange points (km from barycentre) ===\n');
fprintf('L1: x = %.2f km\n', L1 * EarthMoonDistance);
fprintf('L2: x = %.2f km\n', L2 * EarthMoonDistance);
fprintf('L3: x = %.2f km\n', L3 * EarthMoonDistance);

assert(L1 > x1 && L1 < x2, 'L1 not between Earth and Moon');
assert(L2 > x2, 'L2 not to the right of the Moon');
assert(L3 < x1, 'L3 not to the left of the Earth');

dE_L1 = abs(L1 - x1) * EarthMoonDistance;
dM_L1 = abs(x2 - L1) * EarthMoonDistance;

dE_L2 = abs(L2 - x1) * EarthMoonDistance;
dM_L2 = abs(L2 - x2) * EarthMoonDistance;

dE_L3 = abs(L3 - x1) * EarthMoonDistance;
dM_L3 = abs(x2 - L3) * EarthMoonDistance;

fprintf('\n=== Distances to primaries (km) ===\n');
fprintf('L1: Earth %.0f km | Moon %.0f km\n', dE_L1, dM_L1);
fprintf('L2: Earth %.0f km | Moon %.0f km\n', dE_L2, dM_L2);
fprintf('L3: Earth %.0f km | Moon %.0f km\n', dE_L3, dM_L3);

%% Propagate orbits in rotating and inertial frames %%

% Distance from Earth to L1
rE_L1 = abs(L1 - x1);

% Circular orbit at that radius
rp = rE_L1;
ra = rE_L1;

sma = rp;
ecc = 0;

KepAsteroid = [sma ecc inc OM0 om trA];
SV = kep2car(KepAsteroid,1-mu);

