%% Plot_L1L2L3_Circular2BP_vs_CR3BP.m
% Purpose:
%   - Compute Earth-Moon CR3BP collinear Lagrange points (L1/L2/L3)
%   - Plot the points in the rotating barycentric frame
%   - For each Li, build an equivalent *2-body circular orbit about Earth*
%     at radius rE = |Li - x1| (Earth–Moon distance units), i.e. rp=ra=rE
%   - Convert that 2BP inertial state into rotating CR3BP coordinates
%     (same transformation as your lecturer's script) and propagate with CR3BP
%
% Notes:
%   - Uses toolbox functions: getAstroConstants, astroConstants, kep2car,
%     dyn_2BP, trajGet3BP_3D, PlotEarthMoon_system_frame.m, PlotEarthMoon_system_Inertialframe.m
%   - Units are NONDIM in CR3BP: distance = EarthMoonDistance, mu = m2/(m1+m2)
%
clear; clc; close all;

%% PART 0: Setup Earth–Moon system (CR3BP normalised units)
massEarth = getAstroConstants('Earth','mass');
massMoon  = getAstroConstants('Moon','mass');
mu        = massMoon/(massMoon+massEarth);    % CR3BP mass parameter

EarthMoonDistance = 379700; % km (as per your lecture script)

% Primary positions in barycentric rotating frame (nondim)
x1 = -mu;          % Earth
x2 = 1 - mu;       % Moon

%% PART 1: Compute L1/L2/L3 (slide-style piecewise equations)
% Regions:
%   L1: x between Earth and Moon
%   L2: x right of Moon
%   L3: x left of Earth

fL1 = @(x) x ...
    - (1-mu)/(x - x1)^2 ...
    +  mu/(x2 - x)^2;

fL2 = @(x) x ...
    - (1-mu)/(x - x1)^2 ...
    -  mu/(x - x2)^2;

fL3 = @(x) x ...
    + (1-mu)/(x1 - x)^2 ...
    +  mu/(x2 - x)^2;

L1 = fzero(fL1, (x1 + x2)/2);
L2 = fzero(fL2, x2 + 0.2);
L3 = fzero(fL3, -1.2);

% Sanity checks
assert(L1 > x1 && L1 < x2, 'L1 not between Earth and Moon');
assert(L2 > x2,           'L2 not to the right of the Moon');
assert(L3 < x1,           'L3 not to the left of the Earth');

fprintf('\n=== Collinear Lagrange points (non-dimensional x) ===\n');
fprintf('L1: x = %.10f\n', L1);
fprintf('L2: x = %.10f\n', L2);
fprintf('L3: x = %.10f\n', L3);

fprintf('\n=== Collinear Lagrange points (km from barycentre) ===\n');
fprintf('L1: x = %.2f km\n', L1*EarthMoonDistance);
fprintf('L2: x = %.2f km\n', L2*EarthMoonDistance);
fprintf('L3: x = %.2f km\n', L3*EarthMoonDistance);

%% PART 2: Plot Earth–Moon rotating frame and mark L points
figure; hold on; grid on; axis equal;
UnitDistance = EarthMoonDistance;
run PlotEarthMoon_system_frame.m

% Plot L points
plot3(L1,0,0,'ro','MarkerFaceColor','r'); text(L1,0,0,'  L1');
plot3(L2,0,0,'ro','MarkerFaceColor','r'); text(L2,0,0,'  L2');
plot3(L3,0,0,'ro','MarkerFaceColor','r'); text(L3,0,0,'  L3');

title('Earth–Moon rotating barycentric frame: L1/L2/L3 and equivalent 2BP circular orbits');
xlabel('x (nondim)'); ylabel('y (nondim)'); zlabel('z (nondim)');

%% PART 3: For each Li, build equivalent 2BP circular orbit about Earth
% Lecturer instruction interpretation:
%   - Convert Li into rp=ra in Earth–Moon distance units, using distance from Earth:
%       rE = |Li - x1|
%   - Use that as a circular Keplerian orbit around Earth (2BP).
%   - Propagate in 2BP inertial (Earth-centred) to get SV(t) in inertial.
%   - Convert initial SV into rotating barycentric CR3BP frame (same as lecture Part 2).
%   - Propagate in CR3BP with trajGet3BP_3D to compare.

Li_list = [L1, L2, L3];
Li_name = {'L1','L2','L3'};

% Kepler elements (Earth-centred, equatorial, circular)
inc = 0; OM0 = 0; om = 0; trA = 0;

% ODE options
OPTIONS2BP  = odeset('RelTol',3e-10,'AbsTol',1e-12);
OPTIONS3BP  = odeset('RelTol',3e-10,'AbsTol',1e-12);

for k = 1:3
    Li = Li_list(k);
    rE = abs(Li - x1);      % nondim distance from Earth to Li (Earth-centred radius)
    rp = rE; ra = rE;       % circular orbit request
    sma = rE; ecc = 0;

    % Period in normalised units for 2BP around Earth with mu1 = (1-mu)
    mu1 = (1 - mu);
    P   = 2*pi*sqrt(sma^3/mu1);

    % Earth-centred 2BP inertial state from Kepler elements
    Kep = [sma ecc inc OM0 om trA];
    SV  = kep2car(Kep, mu1);     % returns [x;y;z;vx;vy;vz] in Earth-centred inertial frame

    % --- Convert this initial state to barycentric rotating frame (lecture method) ---
    X = SV(1:3).';   % row
    V = SV(4:6).';

    % Translate Earth-centred -> barycentric (Earth is at x1=-mu)
    Xb = [X(1) - mu, X(2), X(3)];
    Vb = [V(1),      V(2), V(3)];

    % In lecture script you also had a V shift line; the correct CR3BP rotating transform is:
    % Rotating frame velocity: v_rot = v_inertial - omega x r, with omega=1 (nondim) about +z
    % That equals: [vx + y, vy - x, vz] when omega=1 and r=[x,y,z]
    Xrot = Xb;
    Vrot = [Vb(1) + Xb(2), Vb(2) - Xb(1), Vb(3)];

    % --- Propagate in CR3BP rotating frame ---
    t0 = 0;
    tf = 4*P;  % same "4 periods" idea as your lecture script
    [SV3,t3] = trajGet3BP_3D([Xrot Vrot], t0, tf, mu, OPTIONS3BP);

    % Plot in rotating frame
    plot3(SV3(:,1), SV3(:,2), SV3(:,3), 'LineWidth', 1.2);
end

legend({'','', '', 'L1','L2','L3','Orbit@L1-radius','Orbit@L2-radius','Orbit@L3-radius'}, ...
       'Location','bestoutside');
view(0,90);