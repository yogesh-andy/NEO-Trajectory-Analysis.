%% Earth -> NEO Rendezvous Porkchop (Falcon Heavy Launch)
%
% Purpose:
%   Grid search over departure date and TOF for Earth -> NEO rendezvous.
%   Maps Falcon Heavy launch performance to delivered mass at the asteroid
%   and onboard DV requirement using impulsive Lambert transfers.
%
% Algorithm (per grid point):
%   1) Earth state at departure (EphSS_car)
%   2) NEO state at arrival (ephNEO -> kep2car)
%   3) Solve Lambert short-way and long-way (LambertArc_ATD2026)
%   4) Select branch with lower DV proxy: ||v1-vE|| + ||vNEO-v2||
%   5) Map Earth v_inf to Falcon Heavy injected wet mass via C3 curve
%      (excess v_inf above launcher max treated as onboard burn)
%   6) Rendezvous braking at arrival: DV_arr ~ v_inf_NEO
%   7) Tsiolkovsky -> delivered mass at asteroid
%
% Assumptions:
%   - Patched-conic screening model (no parking orbit, no DSMs, no
%     finite burns). Intended for trade-space mapping and window finding.
%   - Two-body heliocentric Lambert transfers (single revolution)
%   - Falcon Heavy C3-mass curve (with expandable) from lecture slides
%
% Outputs:
%   - Delivered mass porkchop (full + zoomed)
%   - Onboard DV porkchop (full + zoomed)
%   - Console summary with optimum, feasibility window, key points
%
% Configuration:
%   Set targetStr (NEO name) and grid bounds below.
%
% Dependencies:
%   LambertArc_ATD2026, EphSS_car, ephNEO, kep2car,
%   date2mjd2000, mjd20002date, getAstroConstants

clear; clc; close all

%% ===================== A) Constants and mission parameters =====================
muSun     = getAstroConstants('Sun','mu');   % [km^3/s^2]
secPerDay = 86400;                           % [s/day]

Isp = 345;                    % [s]
g0  = 9.80665;                % [m/s^2] (standard gravity)
ve  = Isp * g0;               % exhaust velocity [m/s]

mDryReq = 2200;               % delivered mass requirement at NEO [kg]

%% ===================== B) Target NEO selection =====================
neoFile   = 'All_NEOS_ATA&TD_2018_2019.csv';
targetStr = '2006 SU49';

neoTbl = readtable(neoFile);
mask   = contains(lower(string(neoTbl.full_name)), lower(targetStr));
idx    = find(mask, 1, 'first');

if isempty(idx)
    error('NEO "%s" not found in %s.', targetStr, neoFile);
end

neoName = strtrim(neoTbl.full_name{idx});
neoID   = 11 + idx;   % ephNEO IDs start at 12

fprintf('\n================ NEO SELECTION ==================\n');
fprintf('Target:    %s\n', targetStr);
fprintf('Matched:   %s (CSV row %d, ephNEO ID %d)\n', neoName, idx, neoID);
fprintf('=================================================\n\n');

%% ===================== C) Falcon Heavy performance (expandable) =====================
C3_vector      = [0 10 20 25 30 40 50 60 70 80 90 100];               % [km^2/s^2]
WetMass_vector = [15000 12300 10100 9100 8200 6600 5200 4100 3100 2200 1400 700];    % [kg]
max_C3   = 40;                                                  % [km^2/s^2]
max_vinf = sqrt(max_C3);                                        % [km/s]

%% ===================== D) Search grid =====================
Dep_Start = date2mjd2000([2029 01 01 0 0 0]);
Dep_End   = date2mjd2000([2029 10 01 0 0 0]);

StepDays      = 5;
Dep_Grid      = Dep_Start : StepDays : Dep_End;
TOF_Grid_days = 50 : StepDays : 200;

nD = numel(Dep_Grid);
nT = numel(TOF_Grid_days);

%% ===================== E) Storage =====================
FinalMassMatrix = NaN(nD, nT);     % delivered mass at NEO [kg]
DVonboardMatrix = NaN(nD, nT);     % total onboard DV [km/s]
vInfE_best      = NaN(nD, nT);     % selected Earth v_inf [km/s]
vInfN_best      = NaN(nD, nT);     % selected NEO v_inf [km/s]
tm_best         = NaN(nD, nT);     % Lambert branch (+1 or -1)

%% ===================== F) Grid scan =====================
for iD = 1:nD
    t_dep = Dep_Grid(iD);

    [r1, vE] = EphSS_car(3, t_dep);
    r1 = r1(:);  vE = vE(:);

    for iT = 1:nT
        tof_days = TOF_Grid_days(iT);
        t_arr    = t_dep + tof_days;
        tof_sec  = tof_days * secPerDay;

        % NEO state at arrival
        [r2, vNEO] = neoState(t_arr, neoID, muSun);
        if isempty(r2), continue; end

        % Best Lambert branch
        [dv, vInfE, vInfN, tm] = bestLambertDV(r1, vE, r2, vNEO, tof_sec, muSun);
        if ~isfinite(dv), continue; end

        vInfE_best(iD,iT) = vInfE;
        vInfN_best(iD,iT) = vInfN;
        tm_best(iD,iT)    = tm;

        % Launcher mass + excess DV
        [mWet, dv_extra] = launcherMass(vInfE, C3_vector, WetMass_vector, ...
                                         max_vinf, max_C3, ve);
        if ~isfinite(mWet) || mWet <= 0, continue; end

        % Rendezvous braking at arrival
        dv_arr     = vInfN;                              % [km/s]
        dv_onboard = dv_extra + dv_arr;                  % [km/s]

        mFinal = mWet * exp(-(dv_arr * 1000) / ve);     % [kg]

        if isfinite(mFinal) && mFinal > 0
            FinalMassMatrix(iD,iT) = mFinal;
            DVonboardMatrix(iD,iT) = dv_onboard;
        end
    end
end

%% ===================== G) Optimum and feasibility =====================
nGrid   = numel(FinalMassMatrix);
nFinite = sum(isfinite(FinalMassMatrix(:)));

bestPt = emptyPick();
if nFinite > 0
    [bestPt.mf, idx] = max(FinalMassMatrix(:), [], 'omitnan');
    [i, j] = ind2sub(size(FinalMassMatrix), idx);

    bestPt.dep   = Dep_Grid(i);
    bestPt.tof   = TOF_Grid_days(j);
    bestPt.arr   = bestPt.dep + bestPt.tof;
    bestPt.vInfE = vInfE_best(i,j);
    bestPt.vInfN = vInfN_best(i,j);
    bestPt.tm    = tm_best(i,j);
    bestPt.dv_ob = DVonboardMatrix(i,j);
end

reqMask = isfinite(FinalMassMatrix) & (FinalMassMatrix >= mDryReq);
nFeas   = sum(reqMask(:));

[depEarliest, depLatest, tofMin, tofMax] = feasibleWindow(reqMask, Dep_Grid, TOF_Grid_days);

%% ===================== H) Plots =====================
X      = Dep_Grid(:).';
Y      = TOF_Grid_days(:).';
Z_mass = FinalMassMatrix.';
Z_dv   = DVonboardMatrix.';

% --- Plot 1A: delivered mass, full window
plotPorkchop(X, Y, Z_mass, 'Delivered mass at NEO [kg]', ...
    sprintf('Earth-NEO Rendezvous (%s): Delivered Mass — Full', neoName), ...
    mDryReq, bestPt, 'full');

% --- Plot 1B: delivered mass, zoomed
plotPorkchop(X, Y, Z_mass, 'Delivered mass at NEO [kg]', ...
    sprintf('Earth-NEO Rendezvous (%s): Delivered Mass — Zoomed', neoName), ...
    mDryReq, bestPt, 'zoom');

% --- Plot 2A: onboard DV, full window
plotPorkchop(X, Y, Z_dv, '\Delta v_{onboard} [km/s]', ...
    sprintf('Earth-NEO Rendezvous (%s): Onboard \\Delta v — Full', neoName), ...
    NaN, bestPt, 'full');

% --- Plot 2B: onboard DV, zoomed (use mass-based zoom region)
plotPorkchop(X, Y, Z_dv, '\Delta v_{onboard} [km/s]', ...
    sprintf('Earth-NEO Rendezvous (%s): Onboard \\Delta v — Zoomed', neoName), ...
    NaN, bestPt, 'zoom', Z_mass, mDryReq);

%% ===================== I) Console summary =====================
fprintf('\n================== SUMMARY ==================\n');
fprintf('Target NEO:        %s (ephNEO ID %d)\n', neoName, neoID);
fprintf('Grid points:       %d\n', nGrid);
fprintf('Finite solutions:  %d (%.1f%%)\n', nFinite, 100*nFinite/nGrid);

if isfinite(bestPt.mf)
    fprintf('\nOptimum (max delivered mass):\n');
    fprintf('  mf     = %.1f kg\n', bestPt.mf);
    fprintf('  Dep    = %s | TOF %.1f d | Arr %s\n', ...
        localDateStr(bestPt.dep), bestPt.tof, localDateStr(bestPt.arr));
    fprintf('  v_inf  = %.3f km/s (Earth) | %.3f km/s (NEO) | C3 = %.2f km^2/s^2\n', ...
        bestPt.vInfE, bestPt.vInfN, bestPt.vInfE^2);
    fprintf('  DV_ob  = %.3f km/s\n', bestPt.dv_ob);
    fprintf('  Branch = %s\n', branchStr(bestPt.tm));
else
    fprintf('\nNo finite Lambert solutions found.\n');
end

fprintf('\nRequirement (mf >= %.0f kg):\n', mDryReq);
fprintf('  Feasible points: %d (%.1f%%)\n', nFeas, 100*nFeas/nGrid);

if nFeas > 0
    fprintf('  Dep window:      %s to %s (step %d d)\n', ...
        localDateStr(depEarliest), localDateStr(depLatest), StepDays);
    fprintf('  TOF range:       %.0f to %.0f days\n', tofMin, tofMax);

    tmFeas = tm_best(reqMask);
    fprintf('  Branch split:    short = %d, long = %d\n', ...
        sum(tmFeas == +1, 'omitnan'), sum(tmFeas == -1, 'omitnan'));
end

fprintf('=============================================\n');

%% =====================================================================
%% Local functions
%% =====================================================================

function [r, v] = neoState(t, id, muSun)
% NEO heliocentric Cartesian state at epoch t.
    try
        kep = ephNEO(t, id);
        st  = kep2car(kep, muSun);
        r = st(1:3)';  r = r(:);
        v = st(4:6)';  v = v(:);
    catch
        r = [];  v = [];
    end
end

function [dvBest, vInfE, vInfN, tmBest] = bestLambertDV(r1, vE, r2, vN, dt_sec, mu)
% Solve both Lambert branches, return the one with lower DV proxy.
    dvBest = inf;  vInfE = NaN;  vInfN = NaN;  tmBest = NaN;

    for tm = [+1, -1]
        try
            sol = LambertArc_ATD2026(r1, r2, dt_sec, tm, mu);

            if any(isnan(sol.v1)) || sol.err_km > 1e-2
                continue
            end

            dv = norm(sol.v1 - vE) + norm(vN - sol.v2);

            if dv < dvBest
                dvBest = dv;
                vInfE  = norm(sol.v1 - vE);
                vInfN  = norm(vN - sol.v2);
                tmBest = tm;
            end
        catch
        end
    end

    if ~isfinite(dvBest), dvBest = NaN; end
end

function [mWet, dv_extra] = launcherMass(vInfE, C3_vec, mass_vec, max_vinf, max_C3, ve)
% Falcon Heavy injected mass from Earth v_inf, with overflow handling.
% Returns injected wet mass and any onboard DV to supplement launcher.
    dv_extra = 0;
    if vInfE <= max_vinf
        mWet = interp1(C3_vec, mass_vec, vInfE^2, 'linear');
    else
        mWet0    = interp1(C3_vec, mass_vec, max_C3, 'linear');
        dv_extra = vInfE - max_vinf;                          % [km/s]
        mWet     = mWet0 * exp(-(dv_extra * 1000) / ve);
    end
end

function out = emptyPick()
    out = struct('dep',NaN,'tof',NaN,'arr',NaN,'mf',NaN, ...
                 'vInfE',NaN,'vInfN',NaN,'tm',NaN,'dv_ob',NaN);
end

function [depE, depL, tofMin, tofMax] = feasibleWindow(reqMask, Dep_Grid, TOF_Grid_days)
    depE = NaN; depL = NaN; tofMin = NaN; tofMax = NaN;
    if ~any(reqMask(:)), return; end

    [iD, iT] = find(reqMask);
    depE   = min(Dep_Grid(iD));
    depL   = max(Dep_Grid(iD));
    tofMin = min(TOF_Grid_days(iT));
    tofMax = max(TOF_Grid_days(iT));
end

function plotPorkchop(X, Y, Z, cbLabel, titleStr, mReq, bestPt, mode, varargin)
% Generic porkchop plot. mode = 'full' or 'zoom'.
% Optional varargin: {Z_ref, thresh_ref} for zoom region based on a
% different quantity (e.g. zoom DV plot using mass-based region).
    figure('Color','w'); hold on; grid on; box on

    contourf(X, Y, Z, 25, 'LineStyle','none');
    cb = colorbar;
    cb.Label.String = cbLabel;
    xlabel('Departure date');
    ylabel('Time of Flight [days]');
    title(titleStr);

    % Feasibility contour (only if mReq is finite)
    if isfinite(mReq)
        [C, h] = contour(X, Y, Z, [mReq mReq], 'k', 'LineWidth', 2);
        try
            clabel(C, h, 'FontSize', 10, 'Color','k', ...
                   'FontWeight','bold', 'LabelSpacing', 450);
        catch
        end
    end

    % Optimum marker
    if isfinite(bestPt.mf)
        plot(bestPt.dep, bestPt.tof, 'kp', 'MarkerFaceColor','w', ...
             'MarkerSize', 11, 'LineWidth', 1.2);
    end

    % Zoom if requested
    if strcmp(mode, 'zoom')
        if nargin >= 10
            Z_ref = varargin{1};  thresh = max(0.4*varargin{2}, 200);
        else
            Z_ref = Z;  thresh = max(0.4*mReq, 200);
        end
        zmask = isfinite(Z_ref) & (Z_ref >= thresh);
        if any(zmask(:))
            [iY, iX] = find(zmask);
            xPad = 0.10 * (X(max(iX)) - X(min(iX)));
            yPad = 0.10 * (Y(max(iY)) - Y(min(iY)));
            xlim([X(min(iX)) - xPad, X(max(iX)) + xPad]);
            ylim([Y(min(iY)) - yPad, Y(max(iY)) + yPad]);
        end
    end

    ax = gca;
    formatDateAxis(ax, ax.XLim);
    hold off
end

function formatDateAxis(ax, xlims)
    xt = linspace(xlims(1), xlims(end), 6);
    ax.XTick = xt;

    xtlbl = strings(size(xt));
    for k = 1:numel(xt)
        d = mjd20002date(xt(k));
        xtlbl(k) = sprintf('%04d-%02d-%02d', d(1), d(2), d(3));
    end

    ax.XTickLabel = xtlbl;
    ax.XTickLabelRotation = 25;
    ax.XMinorGrid = 'on';
    ax.YMinorGrid = 'on';
    ax.MinorGridAlpha = 0.15;
    ax.GridAlpha      = 0.25;
    ax.TickDir        = 'out';
    ax.LineWidth      = 1;
end

function s = branchStr(tm)
    if ~isfinite(tm),  s = 'N/A';
    elseif tm > 0,     s = 'short-way (t_m = +1)';
    else,              s = 'long-way (t_m = -1)';
    end
end

function s = localDateStr(mjd)
    d = mjd20002date(mjd);
    s = sprintf('%04d-%02d-%02d', d(1), d(2), d(3));
end
