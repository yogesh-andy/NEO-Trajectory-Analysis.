%% LambertArc_ATD2026  Robust Lambert arc solver via continuation on time-of-flight
%
% Robust Lambert arc solver using continuation on time-of-flight.
% Gradually shifts from the minimum-energy solution to a desired TOF,
% applying STM corrections until the transfer converges.
%
% Fixes "shooting" miss error by continuation in TOF:
%   1) Start from MinETransfer (easy case at dt_min)
%   2) Walk dt from dt_min -> dt_target over N stages (lambda continuation)
%   3) At each stage, iterate STM correction until |eR| < tol (default 1 m)
%   4) Return converged v1 (departure) and v2 (arrival) for dt_target
%
% Inputs:
%   r1, r2          [km] endpoint position vectors (1x3 or 3x1)
%   TOF_target_sec  [s]  desired time of flight
%   t_m             +1 short-way, -1 long-way
%   mu              [km^3/s^2]
%
% Output (struct):
%   sol.v1      [km/s] departure velocity on transfer (3x1)
%   sol.v2      [km/s] arrival velocity on transfer   (3x1)
%   sol.rf      [km]   propagated final position at TOF_target_sec (3x1)
%   sol.err_km  [km]   final miss distance ||rf - r2||
%   sol.log     per-stage diagnostics

function sol = LambertArc_ATD2026(r1, r2, TOF_target_sec, t_m, mu)

    % ---- force column vectors ----
    r1 = r1(:);
    r2 = r2(:);
    r1mag = norm(r1);

    % ---- Minimum-energy initial guess (seed at dt_min) ----
    outME      = MinETransfer(r1, r2, t_m, mu);
    dt_min_sec = outME.dt_min_sec;
    v1         = outME.r1_dot(:);

    % ---- Parameters (tune as needed) ----
    nStages   = 10;     % continuation stages
    tol_km    = 1e-3;   % 1 m in km
    maxIter   = 25;     % STM corrections per stage

    log(nStages) = struct('Lamda',[],'DT',[],'numIter',[], ...
                          'err_start_km',[],'err_end_km',[], ...
                          'failedHyperbolic',false,'converged',false);

    % ==================== Continuation loop ====================
    for iStage = 1:nStages

        Lamda = iStage / nStages;
        DT    = Lamda*TOF_target_sec + (1 - Lamda)*dt_min_sec;

        % Initial "shoot" at this DT
        r2_iter = FGKepler_dt(DT, r1, v1, mu);
        err0    = norm(r2_iter - r2);
        err     = err0;

        failedHyper = false;
        k = 0;

        % -------- Shooting / differential correction --------
        while (err > tol_km) && (k < maxIter)
            k = k + 1;

            % SMA safety check (elliptic-only): a = mu/(2mu/r - v^2)
            den = (2*mu/r1mag - dot(v1,v1));
            a_seed = mu / den;

            if (a_seed <= 0) || ~isfinite(a_seed)
                warning('LambertArc_ATD2026:Hyperbolic', ...
                        'Stage %d: orbit went hyperbolic (a<=0). Aborting.', iStage);
                failedHyper = true;
                v1 = [NaN; NaN; NaN];
                break
            end

            % One STM correction step (updates v1 to reduce endpoint error)
            step = STM_Lambert(r1, v1, r2, DT, mu);
            v1   = step.v0_new(:);

            % Updated endpoint + error (STM_Lambert already propagated rf_new)
            r2_iter = step.rf_new(:);
            err     = norm(r2_iter - r2);
        end

        % -------- Log stage --------
        log(iStage).Lamda            = Lamda;
        log(iStage).DT               = DT;
        log(iStage).numIter          = k;
        log(iStage).err_start_km     = err0;
        log(iStage).err_end_km       = err;
        log(iStage).failedHyperbolic = failedHyper;
        log(iStage).converged        = (~failedHyper) && (err <= tol_km);

        if failedHyper
            break
        end
    end

    % ==================== Final propagate at TOF_target ====================
    sol = struct();
    sol.log = log;

    if any(isnan(v1))
        sol.v1 = v1;
        sol.v2 = [NaN; NaN; NaN];
        sol.rf = [NaN; NaN; NaN];
        sol.err_km = NaN;
        return
    end

    [rf, outDT] = FGKepler_dt(TOF_target_sec, r1, v1, mu);

    % Arrival velocity formula (lecturer)
    a  = outDT.a;
    dE = outDT.dE;
    G  = outDT.G;

    Gdot = 1 - a/norm(rf) * (1 - cos(dE));
    v2   = (1/G) * (-r1 + Gdot*rf);

    sol.v1     = v1;
    sol.v2     = v2;
    sol.rf     = rf(:);
    sol.err_km = norm(sol.rf - r2);
end