%% MinETransfer  Minimum-energy transfer geometry + TOF (lecture algorithm)
%
% Computes the minimum-energy (Lambert) transfer between two position vectors.
% Returns transfer geometry (a_min, e_min, dt_min) and the required
% departure velocity r1_dot that connects r1 -> r2 under two-body motion.
%
% Given two heliocentric position vectors r1 and r2, computes:
%   - minimum-energy semi-major axis a_min
%   - semi-latus rectum p_min and eccentricity e_min
%   - minimum-energy time of flight dt_min
%   - f,g coefficients at the endpoints, and the implied departure velocity r1_dot
%
% Inputs:
%   r1_vec, r2_vec : endpoint position vectors [km] (1x3 or 3x1)
%   t_m            : +1 short-way, -1 long-way (sets sign of sin(Δθ))
%   mu             : gravitational parameter [km^3/s^2]
%
% Output struct fields match your existing scripts.

function out = MinETransfer(r1_vec, r2_vec, t_m, mu)

    r1_vec = r1_vec(:);
    r2_vec = r2_vec(:);

    r1 = norm(r1_vec);
    r2 = norm(r2_vec);
    c  = norm(r2_vec - r1_vec);   % chord length

    if c < 1e-12
        error('MinETransfer:ChordTooSmall', ...
              'Chord length c is ~0; r1 and r2 nearly identical.');
    end

    % ---- Transfer angle Δθ from dot product (clamp for numeric safety) ----
    cos_dtheta = dot(r1_vec, r2_vec) / (r1*r2);
    cos_dtheta = max(-1, min(1, cos_dtheta));

    dtheta_rad = acos(cos_dtheta);
    sin_dtheta = t_m * sqrt(max(0, 1 - cos_dtheta^2));   % apply short/long sign

    % ---- Minimum-energy ellipse parameters ----
    a_min = 0.25 * (r1 + r2 + c);
    p_min = (r1*r2/c) * (1 - cos_dtheta);

    if p_min <= 0 || ~isfinite(p_min)
        error('MinETransfer:BadPmin', ...
              'Computed p_min is non-positive/invalid; check geometry and inputs.');
    end

    e_min = sqrt(max(0, 1 - p_min/a_min));

    % ---- Beta angle (lecture form), with clamp for asin argument ----
    beta_arg = (2*a_min - c) / (2*a_min);
    beta_arg = max(0, min(1, beta_arg));
    beta_e   = 2 * asin(sqrt(beta_arg));

    % ---- Minimum-energy TOF ----
    dt_min_sec  = sqrt(a_min^3 / mu) * (pi - t_m * (beta_e - sin(beta_e)));
    dt_min_days = dt_min_sec / 86400;

    % ---- Endpoint f,g coefficients + implied departure velocity ----
    F = 1 - (r2/p_min) * (1 - cos_dtheta);
    G = (r2*r1 / sqrt(mu*p_min)) * sin_dtheta;

    r1_dot = (1/G) * (r2_vec - F*r1_vec);

    % ---- Pack outputs ----
    out = struct();
    out.r1_mag     = r1;
    out.r2_mag     = r2;
    out.c          = c;
    out.cos_dtheta = cos_dtheta;
    out.sin_dtheta = sin_dtheta;
    out.dtheta_rad = dtheta_rad;
    out.dtheta_deg = rad2deg(dtheta_rad);

    out.F      = F;
    out.G      = G;
    out.r1_dot = r1_dot;

    out.a_min  = a_min;
    out.p_min  = p_min;
    out.e_min  = e_min;
    out.beta_e = beta_e;

    out.dt_min_sec  = dt_min_sec;
    out.dt_min_days = dt_min_days;
end