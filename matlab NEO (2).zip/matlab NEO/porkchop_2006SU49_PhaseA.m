%% ====================================================================
%%  Earth -> 2006 SU49  |  Phase A/0 Porkchop  |  Falcon Heavy Expended
%%  Written for the ATATD-Toolbox (Yogesh, ATD 2026)
%% ====================================================================
%%
%%  TOOLBOX MAPPING (what this script uses vs your actual files)
%%  -------------------------------------------------------------
%%   LambertArc_ATD2026.m  -> Lambert solver          [used directly]
%%   getAstroConstants.m   -> physical constants       [used directly]
%%   NEO_Yogesh.m          -> NEO ephemeris            [replaces ephNEO]
%%   TButils / ToolBoxM    -> probed for EphSS_car     [fallback built-in]
%%   FGKepler_dt.m         -> NOT used (propagator, not converter)
%%   kep2car               -> NOT in toolbox root      [built-in provided]
%%   EphSS_car             -> NOT confirmed present    [built-in provided]
%%   date2mjd2000          -> probed in TButils        [built-in provided]
%%   mjd20002date          -> probed in TButils        [built-in provided]
%%
%%  SELF-CONTAINED IMPLEMENTATIONS PROVIDED FOR:
%%   kep2car      - classical orbital elements -> Cartesian (perifocal + rotation)
%%   EphSS_car    - Earth heliocentric ecliptic J2000 (analytic mean elements)
%%   date2mjd2000 - calendar [Y M D h m s] -> MJD2000
%%   mjd20002date - MJD2000 -> calendar [Y M D h m s]
%%
%%  HOW TO RUN
%%  ----------
%%  1. Open MATLAB, set working directory to ATATD-Toolbox folder
%%  2. Run:  porkchop_2006SU49_PhaseA
%%  3. Read the DIAGNOSTICS output first — it tells you what was found
%%     and what fallback is active for each dependency.
%%
%%  OUTPUTS
%%  -------
%%   6 figures + console summary with optimal departure date, TOF,
%%   C3, DLA, injected mass, delivered mass for both direct FHE and
%%   FHE + STAR-48BV options.
%% ====================================================================

clear; clc; close all;

%% ====================================================================
%% SECTION 0 — CONFIGURATION
%% ====================================================================
CFG.target_str    = '2006 SU49';
CFG.neo_csv       = 'All_NEOS_ATA&TD_2018_2019.csv';

CFG.m_wet_req     = 10500;   % [kg]  margin-inclusive wet mass (ECSS 20% in)
CFG.Isp_SC        = 316;     % [s]   SC biprop MMH/MON-3
CFG.v_inf_arr_max = 5.0;     % [km/s] max arrival v_inf for biprop braking
CFG.DLA_limit     = 28.5;    % [deg] KSC direct-ascent envelope

CFG.dep_start     = [2029 01 01 0 0 0];
CFG.dep_end       = [2033 01 01 0 0 0];
CFG.step_days     = 5;
CFG.tof_min       = 50;
CFG.tof_max       = 600;

CFG.r_park_km     = 6563.0;   % [km]  185 km altitude parking orbit
CFG.eps_obl_deg   = 23.43928; % [deg] J2000 mean obliquity

%% ====================================================================
%% SECTION 1 — DIAGNOSTICS: map your actual toolbox to script needs
%% ====================================================================
fprintf('\n');
fprintf('=================================================================\n');
fprintf(' ATATD TOOLBOX DIAGNOSTICS\n');
fprintf('=================================================================\n');

%% Check Lambert — critical, no fallback
if exist('LambertArc_ATD2026','file')
    fprintf('  [OK]      LambertArc_ATD2026\n');
else
    fprintf('  [MISSING] LambertArc_ATD2026  <-- CRITICAL, cannot continue\n');
    error('LambertArc_ATD2026 not found. Add toolbox folder to path.');
end

%% Check getAstroConstants
USE.getAstro = exist('getAstroConstants','file') > 0;
if USE.getAstro
    fprintf('  [OK]      getAstroConstants\n');
else
    fprintf('  [MISSING] getAstroConstants   --> built-in fallback\n');
end

%% Check NEO_Yogesh (replaces ephNEO)
USE.NEO_Yogesh = exist('NEO_Yogesh','file') > 0;
if USE.NEO_Yogesh
    fprintf('  [OK]      NEO_Yogesh          (replaces ephNEO)\n');
else
    fprintf('  [MISSING] NEO_Yogesh          --> hard-coded Keplerian fallback\n');
end

%% Check EphSS_car (may be inside TButils or ToolBoxM)
USE.EphSS_car = exist('EphSS_car','file') > 0;
if USE.EphSS_car
    fprintf('  [OK]      EphSS_car\n');
else
    fprintf('  [MISSING] EphSS_car           --> built-in analytic Earth ephemeris\n');
end

%% Check kep2car
USE.kep2car = exist('kep2car','file') > 0;
if USE.kep2car
    fprintf('  [OK]      kep2car\n');
    %% Probe output format so we know how to call it
    try
        AU_t = 1.495978707e8;
        k_t  = [AU_t, 0.0167, 0.0, 0.0, 0.0, 0.0];
        mu_t = 1.32712440018e11;
        no   = nargout(@kep2car);
        if no >= 2
            [rt,vt] = kep2car(k_t, mu_t);
            USE.kep2car_fmt = 'two';
            fprintf('            format: [r,v] = kep2car(kep,mu)\n');
        else
            st = kep2car(k_t, mu_t);
            if numel(st) >= 6
                USE.kep2car_fmt = 'vec6';
                fprintf('            format: rv = kep2car(kep,mu)  [6-vector]\n');
            else
                USE.kep2car_fmt = 'unknown';
                fprintf('            format: UNKNOWN — built-in will be used\n');
                USE.kep2car = false;
            end
        end
    catch ME_k
        fprintf('            probe error: %s -> built-in used\n', ME_k.message);
        USE.kep2car = false;
        USE.kep2car_fmt = 'none';
    end
else
    USE.kep2car_fmt = 'none';
    fprintf('  [MISSING] kep2car             --> built-in implementation\n');
end

%% Check date functions (likely in TButils)
USE.date2mjd = exist('date2mjd2000','file') > 0;
USE.mjd2date = exist('mjd20002date','file') > 0;
fprintf('  %s date2mjd2000\n',  ternary(USE.date2mjd,'[OK]     ','[MISSING]'));
fprintf('  %s mjd20002date\n',  ternary(USE.mjd2date,'[OK]     ','[MISSING]'));
if ~USE.date2mjd || ~USE.mjd2date
    fprintf('            --> built-in Julian Day fallbacks active\n');
end

%% CSV
USE.csv = exist(CFG.neo_csv,'file') > 0;
if USE.csv
    fprintf('  [OK]      CSV: %s\n', CFG.neo_csv);
else
    fprintf('  [MISSING] CSV: %s  --> hard-coded elements\n', CFG.neo_csv);
end

fprintf('=================================================================\n\n');

%% ====================================================================
%% SECTION 2 — PHYSICAL CONSTANTS
%% ====================================================================
if USE.getAstro
    try
        muSun = getAstroConstants('Sun','mu');
        assert(isnumeric(muSun) && muSun > 1e10);
    catch
        muSun = 1.32712440018e11;
    end
else
    muSun = 1.32712440018e11;  % [km3/s2] DE430
end

muEarth   = 398600.4418;
secPerDay = 86400;
g0        = 9.80665;
ve_SC     = CFG.Isp_SC * g0;        % [m/s] ~3099
eps_obl   = CFG.eps_obl_deg*pi/180;
V_esc2    = 2*muEarth/CFG.r_park_km;% [km2/s2] V_escape^2 at perigee

%% ====================================================================
%% SECTION 3 — NEO IDENTIFICATION
%% ====================================================================
neoRow  = [];
neoName = CFG.target_str;

if USE.csv
    try
        T = readtable(CFG.neo_csv, 'VariableNamingRule','preserve');
        %% Find name column robustly
        col_candidates = {'full_name','name','designation','object','Name','FULL_NAME'};
        nameCol = '';
        for cc = col_candidates
            if ismember(cc{1}, T.Properties.VariableNames)
                nameCol = cc{1};  break;
            end
        end
        if isempty(nameCol)
            nameCol = T.Properties.VariableNames{1};
        end
        rawNames = string(T.(nameCol));
        mask     = contains(lower(rawNames), lower(CFG.target_str));
        idx      = find(mask, 1, 'first');
        if ~isempty(idx)
            neoRow  = idx;
            neoName = strtrim(rawNames(idx));
            fprintf('[NEO]  Found "%s" at CSV row %d\n', neoName, idx);
        else
            fprintf('[NEO]  Not found in CSV -> hard-coded fallback\n');
        end
    catch ME
        fprintf('[NEO]  CSV error: %s -> hard-coded fallback\n', ME.message);
    end
end

%% Hard-coded 2006 SU49 Keplerian elements — JPL Horizons J2000.0 epoch
%%   a [km], e, i [rad], RAAN [rad], AoP [rad], M0 [rad]
AU = 1.495978707e8;
NEO_FB.a    = 1.0054 * AU;
NEO_FB.e    = 0.1064;
NEO_FB.i    = 7.25   * pi/180;
NEO_FB.RAAN = 349.7  * pi/180;
NEO_FB.AoP  = 272.3  * pi/180;
NEO_FB.M0   = 12.4   * pi/180;   % at MJD2000 = 0 (J2000.0)

%% Smoke-test NEO_Yogesh if available
USE.neo_ok = false;
if USE.NEO_Yogesh && ~isempty(neoRow)
    try
        t_test = local_date2mjd([2030 6 1 0 0 0]);
        %% NEO_Yogesh may accept (epoch_mjd2000, row_index) or (epoch_mjd2000, name)
        %% Try row index first (most common in ATD toolboxes)
        out = NEO_Yogesh(t_test, neoRow);
        if isnumeric(out) && numel(out) >= 6
            USE.neo_ok   = true;
            USE.neo_fmt  = 'kep6';   % returns 6-element Keplerian vector
            fprintf('[NEO]  NEO_Yogesh(t, row) -> 6-element Keplerian OK\n');
        elseif isnumeric(out) && numel(out) >= 3
            USE.neo_ok   = true;
            USE.neo_fmt  = 'cart3';  % returns position only — try two-output
            fprintf('[NEO]  NEO_Yogesh(t, row) -> position vector (3-elem)\n');
        end
    catch
        try
            %% Try with the name string
            out = NEO_Yogesh(t_test, neoName);
            if isnumeric(out) && numel(out) >= 6
                USE.neo_ok  = true;
                USE.neo_fmt = 'kep6';
                USE.neo_arg = 'name';
                fprintf('[NEO]  NEO_Yogesh(t, name) -> Keplerian OK\n');
            end
        catch
            fprintf('[NEO]  NEO_Yogesh smoke-test failed -> hard-coded fallback\n');
        end
    end
    if ~USE.neo_ok
        fprintf('[NEO]  NEO_Yogesh did not return usable output -> fallback\n');
    end
end
if ~USE.neo_ok
    fprintf('[NEO]  Using hard-coded 2006 SU49 Keplerian elements (verify vs Horizons)\n');
end

if ~isfield(USE,'neo_arg'), USE.neo_arg = 'row'; end
fprintf('\n');

%% ====================================================================
%% SECTION 4 — FHE C3-MASS CURVE
%%   Anchor: 16800 kg @ C3=8.7 km2/s2 (SpaceX Mars TMI, FHE published)
%%   Derived via Tsiolkovsky: Merlin Vacuum Isp=348s, stage inert~4100kg
%% ====================================================================
C3_FHE = [0,    5,    8.7,  10,   15,   20,   25,   30,   40,   50,   60];
m_FHE  = [20900,18400,16800,16300,14400,12800,11400,10200, 8100, 6500, 5100];

max_C3_FHE   = max(C3_FHE);
max_vinf_FHE = sqrt(max_C3_FHE);
C3_ref       = 25.3;
m_ref        = safe_interp1_local(C3_FHE, m_FHE, C3_ref);

fprintf('=================================================================\n');
fprintf(' FHE @ C3 = %.1f km2/s2\n', C3_ref);
fprintf('=================================================================\n');
fprintf('  Derived capability : %.0f kg\n', m_ref);
fprintf('  Requirement        : %.0f kg  (20%% ECSS margin included)\n', CFG.m_wet_req);
fprintf('  Nominal margin     : %+.1f%%\n', (m_ref-CFG.m_wet_req)/CFG.m_wet_req*100);
fprintf('  -10%% band margin  : %+.1f%%\n', (m_ref*0.9-CFG.m_wet_req)/CFG.m_wet_req*100);
fprintf('  ** SpaceX MIA confirmation required before Phase B **\n');
fprintf('=================================================================\n\n');

%% ====================================================================
%% SECTION 5 — STAR-48BV
%% ====================================================================
S48.m_prop  = 2010;
S48.m_inert = 148;
S48.m_total = S48.m_prop + S48.m_inert;   % 2158 kg
S48.m_adap  = 130;
S48.Isp     = 292.3;
S48.ve      = S48.Isp * g0;               % 2867 m/s

m_stack_S48 = CFG.m_wet_req + S48.m_total + S48.m_adap;  % 12788 kg

dV_S48_km = S48.ve * log((CFG.m_wet_req + S48.m_total) / ...
                          (CFG.m_wet_req + S48.m_inert)) / 1000;  % ~0.496 km/s

C3_FH_S48_ref = s48_c3_reduced(C3_ref, dV_S48_km, V_esc2);
m_FHE_S48_ref = safe_interp1_local(C3_FHE, m_FHE, C3_FH_S48_ref);

fprintf('=================================================================\n');
fprintf(' STAR-48BV\n');
fprintf('=================================================================\n');
fprintf('  dV to %.0f kg stack    : %.1f m/s\n', CFG.m_wet_req, dV_S48_km*1000);
fprintf('  FHE stack req.         : %.0f kg\n', m_stack_S48);
fprintf('  FHE C3 target (red.)   : %.2f km2/s2\n', C3_FH_S48_ref);
fprintf('  FHE @ red. C3          : %.0f kg  (margin %+.1f%%)\n', ...
        m_FHE_S48_ref, (m_FHE_S48_ref-m_stack_S48)/m_stack_S48*100);
fprintf('=================================================================\n\n');

%% ====================================================================
%% SECTION 6 — GRID
%% ====================================================================
t0 = local_date2mjd(CFG.dep_start);
t1 = local_date2mjd(CFG.dep_end);

Dep_Grid      = t0 : CFG.step_days : t1;
TOF_Grid_days = CFG.tof_min : CFG.step_days : CFG.tof_max;

nD = numel(Dep_Grid);
nT = numel(TOF_Grid_days);

fprintf('[GRID]  %d departure x %d TOF = %d cells  (step %d d)\n\n', ...
        nD, nT, nD*nT, CFG.step_days);

%% ====================================================================
%% SECTION 7 — STORAGE
%% ====================================================================
mWetMat      = NaN(nD,nT);
mFinalMat    = NaN(nD,nT);
DVonbMat     = NaN(nD,nT);
C3depMat     = NaN(nD,nT);
DLAMat       = NaN(nD,nT);
vInfArrMat   = NaN(nD,nT);
tmMat        = NaN(nD,nT);
mFinal_S48   = NaN(nD,nT);
S48_feas     = false(nD,nT);
S48_C3FH     = NaN(nD,nT);

%% ====================================================================
%% SECTION 8 — MAIN GRID SCAN
%% ====================================================================
fprintf('[SCAN]  Starting...\n');
tw = tic;
n_ok=0; n_lf=0; n_nf=0;

for iD = 1:nD
    t_dep = Dep_Grid(iD);

    %% Earth heliocentric state
    [r1, vE, ok_e] = earth_state(t_dep, USE);
    if ~ok_e, continue; end

    for iT = 1:nT
        tof_d   = TOF_Grid_days(iT);
        t_arr   = t_dep + tof_d;
        tof_sec = tof_d * secPerDay;

        %% NEO heliocentric state
        [r2, vN, ok_n] = neo_state(t_arr, neoRow, neoName, USE, ...
                                    muSun, NEO_FB);
        if ~ok_n, n_nf=n_nf+1; continue; end

        %% Lambert
        [viE_vec, viN, tm, ok_l] = lambert_best(r1, vE, r2, vN, tof_sec, muSun);
        if ~ok_l, n_lf=n_lf+1; continue; end
        n_ok = n_ok+1;

        viE_mag = norm(viE_vec);
        C3dep   = viE_mag^2;
        DLA     = compute_DLA(viE_vec, eps_obl);

        C3depMat(iD,iT)   = C3dep;
        DLAMat(iD,iT)     = DLA;
        vInfArrMat(iD,iT) = viN;
        tmMat(iD,iT)      = tm;

        %% Option 1 — Direct FHE
        [mWet, dv_ex] = fhe_mass(viE_mag, C3_FHE, m_FHE, max_vinf_FHE, ve_SC, V_esc2);
        if isfinite(mWet) && mWet > 0
            dv_ob  = dv_ex + viN;
            mFin   = mWet * exp(-viN*1000/ve_SC);
            mWetMat(iD,iT)   = mWet;
            DVonbMat(iD,iT)  = dv_ob;
            if isfinite(mFin) && mFin > 0
                mFinalMat(iD,iT) = mFin;
            end
        end

        %% Option 2 — FHE + STAR-48BV
        C3r = s48_c3_reduced(C3dep, dV_S48_km, V_esc2);
        if isfinite(C3r) && C3r >= 0 && C3r <= max_C3_FHE
            mFHs = safe_interp1_local(C3_FHE, m_FHE, C3r);
            if isfinite(mFHs) && mFHs >= m_stack_S48
                S48_feas(iD,iT) = true;
                S48_C3FH(iD,iT) = C3r;
                mFs = CFG.m_wet_req * exp(-viN*1000/ve_SC);
                if isfinite(mFs) && mFs > 0
                    mFinal_S48(iD,iT) = mFs;
                end
            end
        end
    end

    %% Progress
    if mod(iD, max(1,floor(nD/20)))==0 || iD==nD
        el  = toc(tw);
        eta = el*(nD-iD)/max(iD,1);
        fprintf('  %4.1f%%  %s  ok=%d fail=%d  ETA=%.0fs\n', ...
                100*iD/nD, local_mjd2str(t_dep), n_ok, n_lf+n_nf, eta);
    end
end

fprintf('[SCAN]  Done %.1fs | ok=%d  Lambert fail=%d  NEO fail=%d\n\n', ...
        toc(tw), n_ok, n_lf, n_nf);

%% ====================================================================
%% SECTION 9 — FEASIBILITY
%% ====================================================================
f_inj  = isfinite(mWetMat)    & (mWetMat    >= CFG.m_wet_req);
f_DLA  = isfinite(DLAMat)     & (abs(DLAMat) <= CFG.DLA_limit);
f_vinf = isfinite(vInfArrMat) & (vInfArrMat  <= CFG.v_inf_arr_max);

f_dir  = f_inj & f_DLA & f_vinf;
f_s48  = S48_feas & f_DLA & f_vinf;

%% ====================================================================
%% SECTION 10 — OPTIMA
%% ====================================================================
BD = best_point(mFinalMat, f_dir, Dep_Grid, TOF_Grid_days, ...
                C3depMat, DLAMat, vInfArrMat, mWetMat, DVonbMat, tmMat, S48_C3FH);
BS = best_point(mFinal_S48, f_s48, Dep_Grid, TOF_Grid_days, ...
                C3depMat, DLAMat, vInfArrMat, mWetMat, DVonbMat, tmMat, S48_C3FH);

%% ====================================================================
%% SECTION 11 — SUMMARY
%% ====================================================================
nGrid = nD*nT;
nFin  = sum(isfinite(mWetMat(:)));

fprintf('=================================================================\n');
fprintf(' RESULTS — %s\n', neoName);
fprintf('=================================================================\n');
fprintf(' Grid    : %s to %s | TOF %d-%dd | step %dd\n', ...
        local_mjd2str(Dep_Grid(1)), local_mjd2str(Dep_Grid(end)), ...
        TOF_Grid_days(1), TOF_Grid_days(end), CFG.step_days);
fprintf(' Cells   : %d | Solutions: %d (%.1f%%)\n', nGrid, nFin, 100*nFin/max(nGrid,1));

n_inj = sum(f_inj(:));  n_dir = sum(f_dir(:));
fprintf('\n  Option 1 — Direct FHE\n');
fprintf('  Injection OK (mWet >= %.0f kg) : %d (%.1f%%)\n', ...
        CFG.m_wet_req, n_inj, 100*n_inj/max(nGrid,1));
fprintf('  All constraints satisfied      : %d (%.1f%%)\n', ...
        n_dir, 100*n_dir/max(nGrid,1));
if n_dir > 0
    [dE,dL,tA,tB] = feas_window(f_dir, Dep_Grid, TOF_Grid_days);
    fprintf('  Departure window : %s to %s\n', local_mjd2str(dE), local_mjd2str(dL));
    fprintf('  TOF range        : %.0f to %.0f days\n', tA, tB);
end
if isfinite(BD.mf)
    fprintf('  Optimum:\n');  print_pt(BD);
else
    fprintf('  [!] No fully feasible direct-FHE point.\n');
    if n_inj > 0
        pDLA = 100*mean(f_inj(:) & ~f_DLA(:));
        pVI  = 100*mean(f_inj(:) & ~f_vinf(:));
        fprintf('      Injection OK but blocked by DLA=%.0f%%  v_inf=%.0f%%\n',pDLA,pVI);
    end
end

DLA_fi = DLAMat(f_inj);
if ~isempty(DLA_fi) && any(isfinite(DLA_fi))
    fprintf('\n  DLA stats (injection-feasible):\n');
    fprintf('  Range: %+.1f to %+.1f deg | >|%.1f|: %.1f%%\n', ...
            min(DLA_fi), max(DLA_fi), CFG.DLA_limit, ...
            100*mean(abs(DLA_fi)>CFG.DLA_limit));
end

n_s48 = sum(f_s48(:));
fprintf('\n  Option 2 — FHE + STAR-48BV\n');
fprintf('  All constraints satisfied : %d (%.1f%%)\n', n_s48, 100*n_s48/max(nGrid,1));
if isfinite(BS.mf)
    fprintf('  Optimum:\n');  print_pt(BS);
    fprintf('    FHE C3 reduced : %.2f km2/s2  (STAR-48 bridges gap)\n', BS.C3r);
    fprintf('    Stack to FHE   : %.0f kg\n', m_stack_S48);
else
    fprintf('  [!] No feasible STAR-48 point in grid.\n');
end

fprintf('\n=================================================================\n\n');

if ~isfinite(BD.mf) && ~isfinite(BS.mf)
    fprintf('[!]  No feasible trajectory found. Checklist:\n');
    fprintf('     1) Widen date range: CFG.dep_end = [2035 01 01 0 0 0]\n');
    fprintf('     2) Extend TOF: CFG.tof_max = 800\n');
    fprintf('     3) If NEO fail count is high, hard-coded elements may need\n');
    fprintf('        updating from JPL Horizons (check M0, a, e for 2006 SU49)\n');
    fprintf('     4) Add ATATD-Toolbox to path: addpath(genpath(''ATATD-Toolbox (2)''))\n\n');
end

%% ====================================================================
%% SECTION 12 — PLOTS
%% ====================================================================
X = Dep_Grid(:).';
Y = TOF_Grid_days(:).';

do_plot(X, Y, mWetMat.', 'FHE injected mass [kg]', ...
    sprintf('FHE Injected Mass — %s', neoName), ...
    mWetMat.', CFG.m_wet_req, 'k', 2.5, sprintf('%.0fkg req',CFG.m_wet_req), '-', ...
    C3depMat.', C3_ref, 'w', 1.5, sprintf('C3=%.1f',C3_ref), '--', ...
    DLAMat.', CFG.DLA_limit, BD, X);

do_plot(X, Y, C3depMat.', 'C3 [km2/s2]', ...
    sprintf('Departure C3 — %s', neoName), ...
    C3depMat.', C3_ref, 'r', 2.5, sprintf('C3=%.1f',C3_ref), '-', ...
    C3depMat.', [10 15 20], 'w', 1.0, 'C3=10,15,20', '--', ...
    DLAMat.', CFG.DLA_limit, BD, X);

do_plot(X, Y, DLAMat.', 'DLA [deg]', ...
    sprintf('Departure DLA (KSC ±%.1f°) — %s', CFG.DLA_limit, neoName), ...
    DLAMat.',  CFG.DLA_limit, 'r', 2.5, sprintf('+%.1f°',CFG.DLA_limit), '-', ...
    DLAMat.', -CFG.DLA_limit, 'r', 2.0, sprintf('-%.1f°',CFG.DLA_limit), '--', ...
    [], 0, BD, X);

do_plot(X, Y, vInfArrMat.', 'Arrival v-inf [km/s]', ...
    sprintf('Arrival v∞ at NEO — %s', neoName), ...
    vInfArrMat.', CFG.v_inf_arr_max, 'r', 2.5, sprintf('%.1fkm/s limit',CFG.v_inf_arr_max), '-', ...
    mWetMat.', CFG.m_wet_req, 'k', 1.5, sprintf('mWet=%.0fkg',CFG.m_wet_req), '--', ...
    DLAMat.', CFG.DLA_limit, BD, X);

do_plot(X, Y, mFinalMat.', 'Delivered mass [kg]', ...
    sprintf('Delivered Mass (Direct FHE) — %s', neoName), ...
    mFinalMat.', CFG.m_wet_req*0.4, 'k', 2.5, '~dry mass', '-', ...
    C3depMat.', C3_ref, 'w', 1.5, sprintf('C3=%.1f',C3_ref), '--', ...
    DLAMat.', CFG.DLA_limit, BD, X);

Z6 = mFinal_S48.';  Z6(~S48_feas.') = NaN;
do_plot(X, Y, Z6, 'Delivered mass [kg]  (STAR-48BV)', ...
    sprintf('Delivered Mass (FHE + STAR-48BV) — %s', neoName), ...
    C3depMat.', C3_ref, 'w', 1.5, sprintf('C3=%.1f',C3_ref), '--', ...
    [], 0, [], 0, ...
    DLAMat.', CFG.DLA_limit, BS, X);

fprintf('[DONE]  All figures rendered.\n\n');

%% ====================================================================
%%  LOCAL FUNCTIONS  — all self-contained, no external dependencies
%% ====================================================================

%% ----------------------------------------------------------------
%% EARTH STATE  (built-in analytic or EphSS_car if present)
%% ----------------------------------------------------------------
function [r1, v1, ok] = earth_state(t_mjd, USE)
%EARTH_STATE  Earth heliocentric ecliptic J2000 state at MJD2000 epoch.
%  Tries EphSS_car first; falls back to analytic mean elements.
    ok = false;  r1 = [];  v1 = [];

    if USE.EphSS_car
        try
            [ra, va] = EphSS_car(3, t_mjd);
            if isnumeric(ra) && numel(ra)>=3 && isnumeric(va) && numel(va)>=3
                r1 = ra(1:3)(:);  v1 = va(1:3)(:);
                if all(isfinite(r1)) && norm(r1)>1e6
                    ok = true;  return;
                end
            end
            %% Single-vector form
            st = EphSS_car(3, t_mjd);
            if isnumeric(st) && numel(st)>=6
                r1 = st(1:3)(:);  v1 = st(4:6)(:);
                if all(isfinite(r1)) && norm(r1)>1e6
                    ok = true;  return;
                end
            end
        catch
        end
    end

    %% Built-in: analytic Earth ephemeris (mean ecliptic J2000 elements)
    %%   Accuracy: ~10^-3 AU over decades — sufficient for porkchop screening
    %%   Reference: Standish & Williams, Orbital Ephemerides of the Sun,
    %%              Moon and Planets, IAU WGAS sub-group on planetary ephemerides
    try
        T_jul = t_mjd / 36525;  % Julian centuries from J2000.0
        AU    = 1.495978707e8;  % [km/AU]

        a0 = 1.000001018;                               % [AU]
        e0 = 0.01670862  - 0.000042037*T_jul;
        i0 = (0.0       - 0.01294668*T_jul) * pi/180;  % [rad] (nearly zero)
        W  = (174.873174 + 0.32327364*T_jul) * pi/180; % long of asc node
        w  = (102.937348 + 0.32327364*T_jul) * pi/180; % long of perihelion
        L0 = (100.464572 + 35999.37244981*T_jul);       % mean longitude [deg]
        L0 = mod(L0, 360) * pi/180;

        M_earth = L0 - w;
        M_earth = mod(M_earth, 2*pi);

        E_earth = solve_kepler_local(M_earth, e0);
        nu = 2*atan2(sqrt(1+e0)*sin(E_earth/2), sqrt(1-e0)*cos(E_earth/2));

        kep = [a0*AU, e0, i0, W, w-W, nu];
        [r1, v1] = kep2car_local(kep, 1.32712440018e11);
        if all(isfinite(r1)) && norm(r1)>1e6
            ok = true;
        end
    catch
    end
end

%% ----------------------------------------------------------------
%% NEO STATE
%% ----------------------------------------------------------------
function [r2, v2, ok] = neo_state(t_mjd, neoRow, neoName, USE, muSun, NEO_FB)
%NEO_STATE  Heliocentric ecliptic J2000 Cartesian state for 2006 SU49.
%  Priority: NEO_Yogesh (toolbox) -> propagated hard-coded elements
    ok = false;  r2 = [];  v2 = [];

    if USE.neo_ok && ~isempty(neoRow)
        try
            if strcmp(USE.neo_arg,'row')
                kep = NEO_Yogesh(t_mjd, neoRow);
            else
                kep = NEO_Yogesh(t_mjd, neoName);
            end

            if isnumeric(kep) && numel(kep) >= 6
                [r2, v2] = kep2car_local(kep(:)', muSun);
                if all(isfinite(r2)) && norm(r2) > 1e6
                    ok = true;  return;
                end
            end

            %% NEO_Yogesh might return [r,v] directly (Cartesian)
            if isnumeric(kep) && numel(kep) >= 6
                r2 = kep(1:3)(:);  v2 = kep(4:6)(:);
                if all(isfinite(r2)) && norm(r2) > 1e6
                    ok = true;  return;
                end
            end
        catch
        end
    end

    %% Also try NEO_Yogesh_Orbit if present
    if ~ok && exist('NEO_Yogesh_Orbit','file') && ~isempty(neoRow)
        try
            kep = NEO_Yogesh_Orbit(t_mjd, neoRow);
            if isnumeric(kep) && numel(kep) >= 6
                [r2, v2] = kep2car_local(kep(:)', muSun);
                if all(isfinite(r2)) && norm(r2) > 1e6
                    ok = true;  return;
                end
            end
        catch
        end
    end

    %% Fallback: propagate hard-coded Keplerian elements
    try
        dt_sec  = t_mjd * 86400;
        n_rad   = sqrt(muSun / NEO_FB.a^3);
        M       = mod(NEO_FB.M0 + n_rad*dt_sec, 2*pi);
        E       = solve_kepler_local(M, NEO_FB.e);
        nu      = 2*atan2(sqrt(1+NEO_FB.e)*sin(E/2), sqrt(1-NEO_FB.e)*cos(E/2));
        kep     = [NEO_FB.a, NEO_FB.e, NEO_FB.i, NEO_FB.RAAN, NEO_FB.AoP, nu];
        [r2,v2] = kep2car_local(kep, muSun);
        if all(isfinite(r2)) && norm(r2) > 1e6
            ok = true;
        end
    catch
    end
end

%% ----------------------------------------------------------------
%% KEP2CAR — pure MATLAB, no toolbox needed
%%   Input kep = [a(km), e, i(rad), RAAN(rad), AoP(rad), nu(rad)]
%% ----------------------------------------------------------------
function [r_eci, v_eci] = kep2car_local(kep, mu)
%KEP2CAR_LOCAL  Classical orbital elements to Cartesian state.
%  Uses perifocal frame + rotation by RAAN, i, AoP.
%  Reference: Bate, Mueller & White, "Fundamentals of Astrodynamics", §2.4

    a    = kep(1);  e   = kep(2);  inc  = kep(3);
    RAAN = kep(4);  AoP = kep(5);  nu   = kep(6);

    %% Sanity clamp
    e   = max(0, min(e, 0.9999));
    inc = mod(inc + pi, 2*pi) - pi;   % keep in (-pi, pi]

    p = a * (1 - e^2);                % semi-latus rectum
    if p <= 0, p = abs(a)*(1-e^2)+1e-6; end

    r_mag = p / (1 + e*cos(nu));

    %% Perifocal frame
    r_pf = r_mag * [cos(nu); sin(nu); 0];
    h_pf = sqrt(mu*p);
    v_pf = (mu/h_pf) * [-sin(nu); e+cos(nu); 0];

    %% Rotation matrix: perifocal -> ecliptic/inertial
    %%   R = Rz(-RAAN) * Rx(-inc) * Rz(-AoP)
    cO=cos(RAAN); sO=sin(RAAN);
    ci=cos(inc);  si=sin(inc);
    cw=cos(AoP);  sw=sin(AoP);

    R = [ cO*cw - sO*sw*ci,  -cO*sw - sO*cw*ci,   sO*si;
          sO*cw + cO*sw*ci,  -sO*sw + cO*cw*ci,  -cO*si;
          sw*si,               cw*si,               ci  ];

    r_eci = R * r_pf;
    v_eci = R * v_pf;
end

%% ----------------------------------------------------------------
%% KEPLER EQUATION SOLVER (Newton-Raphson)
%% ----------------------------------------------------------------
function E = solve_kepler_local(M, ecc, tol)
    if nargin < 3, tol = 1e-12; end
    E = M;
    for k = 1:60
        dE = -(E - ecc*sin(E) - M) / (1 - ecc*cos(E));
        E  = E + dE;
        if abs(dE) < tol, return; end
    end
end

%% ----------------------------------------------------------------
%% LAMBERT SOLVER WRAPPER
%% ----------------------------------------------------------------
function [viE_vec, viN_mag, tmBest, ok] = lambert_best(r1, vE, r2, vN, tof, mu)
%LAMBERT_BEST  Both branches; returns best (lower DV proxy).
    viE_vec = [NaN;NaN;NaN];  viN_mag = NaN;  tmBest = NaN;  ok = false;
    dvBest  = inf;

    for tm = [1, -1]
        try
            sol = LambertArc_ATD2026(r1, r2, tof, tm, mu);

            v1 = field_first(sol, {'v1','V1','vt1','v1_vec'});
            v2 = field_first(sol, {'v2','V2','vt2','v2_vec'});
            if isempty(v1) || isempty(v2), continue; end
            v1 = v1(:);  v2 = v2(:);
            if any(~isfinite(v1)) || any(~isfinite(v2)), continue; end

            %% Convergence check (tolerant to missing field)
            err = field_first(sol, {'err_km','err','residual','tof_err','error'});
            if ~isempty(err) && isfinite(err) && abs(err) > 1.0, continue; end

            vi  = v1 - vE(:);
            va  = vN(:) - v2;
            dv  = norm(vi) + norm(va);

            if dv < dvBest
                dvBest  = dv;
                viE_vec = vi;
                viN_mag = norm(va);
                tmBest  = tm;
                ok      = true;
            end
        catch
        end
    end
end

function val = field_first(s, names)
    val = [];
    for n = names
        if isfield(s, n{1}), val = s.(n{1}); return; end
    end
end

%% ----------------------------------------------------------------
%% DLA COMPUTATION
%% ----------------------------------------------------------------
function DLA = compute_DLA(v_inf_ecl, eps)
%COMPUTE_DLA  Declination of Launch Asymptote from ecliptic J2000 v_inf.
%  Rotate ecliptic J2000 -> geocentric equatorial J2000 by obliquity eps.
%  Ref: Vallado "Fundamentals of Astrodynamics", 4th ed., §3.7
    ce = cos(eps);  se = sin(eps);
    vq = [v_inf_ecl(1);
          ce*v_inf_ecl(2) - se*v_inf_ecl(3);
          se*v_inf_ecl(2) + ce*v_inf_ecl(3)];
    vm = norm(vq);
    if vm < 1e-12, DLA = 0;
    else,          DLA = asind(vq(3)/vm);
    end
end

%% ----------------------------------------------------------------
%% FHE MASS  (perigee-burn physics, not naive v_inf subtraction)
%% ----------------------------------------------------------------
function [mWet, dv_ex] = fhe_mass(viE, C3v, mv, max_vi, ve_ms, V_esc2)
    dv_ex = 0;
    if viE <= max_vi
        mWet  = safe_interp1_local(C3v, mv, viE^2);
    else
        C3max = max_vi^2;
        mWet0 = safe_interp1_local(C3v, mv, C3max);
        dv_ex = sqrt(V_esc2+viE^2) - sqrt(V_esc2+C3max);  % [km/s]
        mWet  = mWet0 * exp(-dv_ex*1000/ve_ms);
    end
    if ~isfinite(mWet) || mWet <= 0, mWet = NaN; dv_ex = NaN; end
end

%% ----------------------------------------------------------------
%% STAR-48BV REDUCED C3
%% ----------------------------------------------------------------
function C3r = s48_c3_reduced(C3req, dV_km, V_esc2)
    if ~isfinite(C3req) || C3req < 0, C3r = NaN; return; end
    Vd  = sqrt(V_esc2 + C3req) - dV_km;
    if Vd <= 0, C3r = NaN; return; end
    C3r = max(Vd^2 - V_esc2, 0);
end

%% ----------------------------------------------------------------
%% SAFE INTERP1
%% ----------------------------------------------------------------
function y = safe_interp1_local(xv, yv, xi)
    if ~isfinite(xi) || xi < min(xv) || xi > max(xv)
        y = NaN; return;
    end
    y = interp1(xv, yv, xi, 'linear');
end

%% ----------------------------------------------------------------
%% FIND BEST POINT
%% ----------------------------------------------------------------
function B = best_point(Zmat, fmask, Dg, Tg, C3m, DLAm, VIm, mWm, DVm, tmm, C3FH)
    B = struct('dep',NaN,'tof',NaN,'arr',NaN,'mf',NaN,'C3',NaN, ...
               'DLA',NaN,'vInfArr',NaN,'mWet',NaN,'dv_ob',NaN, ...
               'tm',NaN,'C3r',NaN);
    Z = Zmat;
    Z(~fmask) = NaN;
    if all(~isfinite(Z(:))), return; end
    [B.mf, lin] = max(Z(:),[],'omitnan');
    if ~isfinite(B.mf), return; end
    [iD,iT] = ind2sub(size(Z), lin);
    B.dep     = Dg(iD);   B.tof    = Tg(iT);
    B.arr     = B.dep+B.tof;
    B.C3      = C3m(iD,iT); B.DLA  = DLAm(iD,iT);
    B.vInfArr = VIm(iD,iT); B.mWet = mWm(iD,iT);
    B.dv_ob   = DVm(iD,iT); B.tm   = tmm(iD,iT);
    B.C3r     = C3FH(iD,iT);
end

function print_pt(B)
    fprintf('    Dep    : %s\n',         local_mjd2str(B.dep));
    fprintf('    TOF    : %.1f days\n',  B.tof);
    fprintf('    Arr    : %s\n',         local_mjd2str(B.arr));
    fprintf('    C3     : %.3f km2/s2\n',B.C3);
    fprintf('    DLA    : %+.2f deg\n',  B.DLA);
    fprintf('    v_inf_a: %.3f km/s\n',  B.vInfArr);
    fprintf('    mWet   : %.0f kg\n',    B.mWet);
    fprintf('    mFinal : %.0f kg\n',    B.mf);
    fprintf('    DV_ob  : %.3f km/s\n',  B.dv_ob);
    if isfinite(B.tm)
        if B.tm>0, fprintf('    Branch : short-way\n');
        else,      fprintf('    Branch : long-way\n'); end
    end
end

function [dE,dL,t1,t2] = feas_window(mask, Dg, Tg)
    [iD,iT] = find(mask);
    dE=min(Dg(iD)); dL=max(Dg(iD)); t1=min(Tg(iT)); t2=max(Tg(iT));
end

%% ----------------------------------------------------------------
%% DATE UTILITIES — pure MATLAB fallbacks
%% ----------------------------------------------------------------
function mjd = local_date2mjd(dv)
    try
        mjd = date2mjd2000(dv);
        assert(isfinite(mjd));
    catch
        yr=dv(1); mo=dv(2); dy=dv(3);
        hr=0; mn=0; sc=0;
        if numel(dv)>=4, hr=dv(4); end
        if numel(dv)>=5, mn=dv(5); end
        if numel(dv)>=6, sc=dv(6); end
        jd = 367*yr - floor(7*(yr+floor((mo+9)/12))/4) + ...
             floor(275*mo/9) + dy + 1721013.5 + (hr+mn/60+sc/3600)/24;
        mjd = jd - 2451545.0;
    end
end

function s = local_mjd2str(mjd)
    if ~isfinite(mjd), s='N/A'; return; end
    try
        d = mjd20002date(mjd);
        s = sprintf('%04d-%02d-%02d', d(1),d(2),d(3));
    catch
        jd = mjd + 2451545.0;
        z  = floor(jd+0.5);
        a  = floor((z-1867216.25)/36524.25);
        a  = z+1+a-floor(a/4);
        b  = a+1524;  c=floor((b-122.1)/365.25);
        d2 = floor(365.25*c);  e=floor((b-d2)/30.6001);
        dy = b-d2-floor(30.6001*e);
        if e<14, mo=e-1; else, mo=e-13; end
        if mo>2, yr=c-4716; else, yr=c-4715; end
        s = sprintf('%04d-%02d-%02d', yr, mo, dy);
    end
end

function s = ternary(cond, a, b)
    if cond, s=a; else, s=b; end
end

%% ----------------------------------------------------------------
%% PLOT ENGINE
%% ----------------------------------------------------------------
function do_plot(X, Y, Z, cblabel, ttl, ...
                 Zc1, lv1, col1, lw1, nm1, ls1, ...
                 Zc2, lv2, col2, lw2, nm2, ls2, ...
                 DLAmat, DLA_lim, best, Xfull)
%DO_PLOT  Generic porkchop figure. Contour overlays silently skip if
%         levels are outside data range or Z is all-NaN.

    figure('Color','w','NumberTitle','off','Name',ttl);
    hold on; grid on; box on;

    %% Base filled contour
    Zp = Z;  Zp(~isfinite(Zp)) = NaN;
    if all(~isfinite(Zp(:)))
        text(mean(X,'omitnan'), mean(Y,'omitnan'), 'No finite data', ...
             'HorizontalAlignment','center','Color','r','FontSize',12);
        xlabel('Departure date'); ylabel('TOF [days]');
        title(ttl,'FontWeight','normal');
        fmt_xaxis(gca, Xfull);  hold off;  return;
    end
    zlo   = min(Zp(:),[],'omitnan');
    Zfill = Zp;  Zfill(~isfinite(Zfill)) = zlo - abs(zlo)*0.02 - 1;
    contourf(X, Y, Zfill, 30, 'LineStyle','none');
    cb = colorbar;  cb.Label.String = cblabel;  cb.Label.FontSize = 10;

    %% Overlay 1
    if ~isempty(Zc1)
        draw_cline(X, Y, Zc1, lv1, col1, lw1, nm1, ls1);
    end
    %% Overlay 2
    if ~isempty(Zc2) && ~isequal(lv2, 0)
        draw_cline(X, Y, Zc2, lv2, col2, lw2, nm2, ls2);
    end
    %% DLA overlay
    if ~isempty(DLAmat) && DLA_lim > 0
        draw_DLA(X, Y, DLAmat, DLA_lim);
    end
    %% Optimum marker
    if isstruct(best) && isfinite(best.dep) && isfinite(best.tof)
        plot(best.dep, best.tof, 'kp', 'MarkerFaceColor','w', ...
             'MarkerSize',12, 'LineWidth',1.5, 'DisplayName','Optimum');
    end

    legend('Location','northeast','FontSize',8,'Box','off');
    xlabel('Departure date','FontSize',10);
    ylabel('Time of flight [days]','FontSize',10);
    title(ttl,'FontWeight','normal');
    fmt_xaxis(gca, Xfull);
    hold off;
end

function draw_cline(X, Y, Zc, levels, clr, lw, nm, ls)
    Zf = Zc;  Zf(~isfinite(Zf)) = NaN;
    if all(~isfinite(Zf(:))), return; end
    zlo = min(Zf(:),[],'omitnan');  zhi = max(Zf(:),[],'omitnan');
    lvls = levels(levels >= zlo & levels <= zhi);
    if isempty(lvls), return; end
    Zfill = Zf;  Zfill(~isfinite(Zfill)) = zlo-1;
    try
        [~,h] = contour(X, Y, Zfill, [lvls lvls], ...
                        'LineColor',clr,'LineStyle',ls,'LineWidth',lw);
        h.DisplayName = nm;
    catch; end
end

function draw_DLA(X, Y, DLAmat, lim)
    Zd = DLAmat;  Zd(~isfinite(Zd)) = NaN;
    if all(~isfinite(Zd(:))), return; end
    Zfill = Zd;  mn = min(Zd(:),[],'omitnan');
    Zfill(~isfinite(Zfill)) = mn-1;
    mx = max(Zd(:),[],'omitnan');
    if lim <= mx
        try
            [~,h] = contour(X,Y,Zfill,[lim lim],'m','LineWidth',1.5);
            h.DisplayName = sprintf('DLA=+%.1f°',lim);
        catch; end
    end
    if -lim >= mn
        try
            [~,h] = contour(X,Y,Zfill,[-lim -lim],'m--','LineWidth',1.5);
            h.DisplayName = sprintf('DLA=−%.1f°',lim);
        catch; end
    end
end

function fmt_xaxis(ax, X)
    try
        xl = [min(X) max(X)];
        if diff(xl)<1, return; end
        xt = linspace(xl(1),xl(2),7);
        ax.XTick = xt;
        lb = strings(size(xt));
        for k=1:numel(xt), lb(k) = local_mjd2str(xt(k)); end
        ax.XTickLabel = lb;
        ax.XTickLabelRotation = 25;
        ax.XMinorGrid='on'; ax.YMinorGrid='on';
        ax.MinorGridAlpha=0.15; ax.GridAlpha=0.25;
        ax.TickDir='out'; ax.LineWidth=1; ax.FontSize=9;
    catch; end
end
