%% MPATD 2025–26 – Exercise 2 (Orbit Visualisation)
% Visualise the selected Earth -> NEO Lambert transfer from Exercise 2.

clear; % clc; close all

%% ===================== 1) Inputs (chosen solution) =====================
idNEO = 18057;      % 2006 SU49

% Optimum (minimum ∆v) from Assessment2_NEO_L2
t_dep = date2mjd2000([2028 01 01 0 0 0]);
t_arr = date2mjd2000([2029 06 19 0 0 0]);
t_m   = -1;    % long way

% Fastest (minimum TOF) from Assessment2_NEO_L2
% t_dep = date2mjd2000([2029 01 21 0 0 0]);
% t_arr = date2mjd2000([2029 02 13 0 0 0]);
% t_m   = +1;    % short way

%% ===================== 2) Constants =====================
muSun     = getAstroConstants('Sun','mu');
secPerDay = 86400;

dt_sec   = (t_arr - t_dep) * secPerDay;
tof_days = dt_sec / secPerDay;

pathStr = ternary(t_m > 0, 'short-way (t_m = +1)', 'long-way  (t_m = -1)');

%% ===================== 3) Endpoint states =====================
[rE_dep, vE_dep] = earthState(t_dep);
[rN_arr, vN_arr] = neoState(t_arr, idNEO, muSun);

fprintf('\n============= EX2 ORBIT VISUALISATION =============\n');
fprintf('NEO ID          = %d\n', idNEO);
fprintf('Departure       = %s\n', localDateStr(t_dep));
fprintf('Arrival         = %s\n', localDateStr(t_arr));
fprintf('TOF             = %.1f days\n', tof_days);
fprintf('Lambert branch  = %s\n', pathStr);
fprintf('===================================================\n\n');

%% ===================== 4) Lambert transfer solve =====================
sol   = LambertArc_ATD2026(rE_dep, rN_arr, dt_sec, t_m, muSun);
vTdep = sol.v1(:);
vTarr = sol.v2(:);

fprintf('Lambert miss (solver) = %.3e km\n\n', sol.err_km);

%% ===================== 5) DV proxy diagnostics =====================
vInf_E   = norm(vTdep - vE_dep);
vInf_NEO = norm(vN_arr - vTarr);

fprintf('v∞_Earth  = %.3f km/s\n', vInf_E);
fprintf('v∞_NEO    = %.3f km/s\n', vInf_NEO);
fprintf('DV proxy  = %.3f km/s\n\n', vInf_E + vInf_NEO);

fprintf('Angle(vE_dep, vT_dep)   = %.2f deg\n', angleDeg(vE_dep, vTdep));
fprintf('Angle(vNEO_arr, vT_arr) = %.2f deg\n\n', angleDeg(vN_arr, vTarr));

%% ===================== 6) Orbit sweeps + propagation =====================
nPts = 250;

[rE0, vE0] = earthState(t_dep);
[rN0, vN0] = neoState(t_dep, idNEO, muSun);

rEarth = sweepOrbitTA(rE0, vE0, muSun, nPts);
rNEO   = sweepOrbitTA(rN0, vN0, muSun, nPts);

tspan = linspace(0, dt_sec, nPts);
rT    = propagateArc(rE_dep, vTdep, muSun, tspan);

fprintf('[Plot check] Transfer endpoint miss = %.3e km\n\n', ...
        norm(rT(end,:).' - rN_arr));

%% ===================== 7) Plot (2D XY) =====================

% Colour scheme (clean & readable)
earthCol = [0.25 0.45 0.85];      % softened blue
neoCol   = [0.55 0.27 0.07];      % brown
transCol = [0.85 0.55 0.10];      % warm transfer colour

figure('Color','w'); hold on; grid on; axis equal; box on

plot(rEarth(:,1), rEarth(:,2), 'Color', earthCol, 'LineWidth', 1.2);
plot(rNEO(:,1),   rNEO(:,2),   'Color', neoCol,   'LineWidth', 1.2);
plot(rT(:,1),     rT(:,2),     '--', 'Color', transCol, 'LineWidth', 1.8);

plot(0,0,'o','MarkerFaceColor','y','MarkerEdgeColor','k','MarkerSize',10);
plot(rE_dep(1), rE_dep(2), 'o', ...
    'MarkerFaceColor', earthCol, 'MarkerEdgeColor','k','MarkerSize',7);
plot(rN_arr(1), rN_arr(2), 'o', ...
    'MarkerFaceColor', neoCol, 'MarkerEdgeColor','k','MarkerSize',6);

xlabel('x [km]'); ylabel('y [km]');
title(sprintf('Exercise 2: Earth \\rightarrow NEO Lambert Transfer (ID %d)', idNEO));
legend('Earth orbit','NEO orbit','Transfer','Sun','Earth dep','NEO arr', ...
       'Location','best');
hold off

%% ===================== 8) Plot (3D) =====================
figure('Color','w'); hold on; grid on; axis equal; box on

L = 2.6e8;
[Xp,Yp] = meshgrid(linspace(-L,L,2));
surf(Xp,Yp,zeros(size(Xp)), ...
     'FaceAlpha',0.05,'EdgeColor','none');

plot3(rEarth(:,1), rEarth(:,2), rEarth(:,3), ...
      'Color', earthCol, 'LineWidth',1.2);
plot3(rNEO(:,1),   rNEO(:,2),   rNEO(:,3), ...
      'Color', neoCol, 'LineWidth',1.2);
plot3(rT(:,1),     rT(:,2),     rT(:,3), ...
      '--','Color', transCol,'LineWidth',1.8);

plot3(0,0,0,'o','MarkerFaceColor','y','MarkerEdgeColor','k','MarkerSize',10);
plot3(rE_dep(1), rE_dep(2), rE_dep(3), 'o', ...
      'MarkerFaceColor', earthCol, 'MarkerEdgeColor','k','MarkerSize',7);
plot3(rN_arr(1), rN_arr(2), rN_arr(3), 'o', ...
      'MarkerFaceColor', neoCol, 'MarkerEdgeColor','k','MarkerSize',6);

view(35,20); axis vis3d; rotate3d on
xlabel('x [km]'); ylabel('y [km]'); zlabel('z [km]');
title(sprintf('Exercise 2: 3D Lambert Transfer (ID %d)', idNEO));
legend('Reference plane','Earth orbit','NEO orbit','Transfer','Sun','Earth dep','NEO arr', ...
       'Location','best');
hold off

%% ===================== Local functions =====================

function [rE, vE] = earthState(t)
    [rE, vE] = EphSS_car(3, t);
    rE = rE(:); vE = vE(:);
end

function [rN, vN] = neoState(t, id, muSun)
    kep = ephNEO(t, id);
    st  = kep2car(kep, muSun);
    rN  = st(1:3).'; rN = rN(:);
    vN  = st(4:6).'; vN = vN(:);
end

function r = sweepOrbitTA(r0, v0, mu, nPts)
    th = linspace(0, 2*pi, nPts);
    r  = zeros(nPts,3);
    for k = 1:nPts
        r(k,:) = FGKepler_trA(th(k), r0, v0, mu).';
    end
end

function r = propagateArc(r0, v0, mu, tspan)
    r = zeros(numel(tspan),3);
    for k = 1:numel(tspan)
        r(k,:) = FGKepler_dt(tspan(k), r0, v0, mu).';
    end
end

function a = angleDeg(u, v)
    c = dot(u,v)/(norm(u)*norm(v));
    c = max(-1, min(1, c));
    a = acosd(c);
end

function out = ternary(cond, a, b)
    if cond, out = a; else, out = b; end
end

function s = localDateStr(mjd)
    d = mjd20002date(mjd);
    s = sprintf('%04d-%02d-%02d', d(1), d(2), d(3));
end