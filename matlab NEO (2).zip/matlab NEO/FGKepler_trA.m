%% FGKepler_trA  f-g propagation (elliptic) using delta true anomaly Δθ
%
% Propagates a two-body orbit using Lagrange F & G coefficients as a
% function of delta true anomaly (Δθ).
% Returns the new position vector without numerical integration.
%
% Inputs:
%   dtheta : delta true anomaly [rad]
%   r0_vec : initial position [km] (1x3 or 3x1)
%   v0_vec : initial velocity [km/s] (1x3 or 3x1)
%   mu     : gravitational parameter [km^3/s^2]
%
% Outputs:
%   rf     : propagated position [km] (3x1)
%   out    : (optional) struct with intermediate values (p,h,F,G, ...)

function [rf, out] = FGKepler_trA(dtheta, r0_vec, v0_vec, mu)

    r0_vec = r0_vec(:);
    v0_vec = v0_vec(:);

    r0 = norm(r0_vec);

    % ---- Angular momentum and semi-latus rectum ----
    h_vec = cross(r0_vec, v0_vec);
    h     = norm(h_vec);
    p     = h^2 / mu;

    if p <= 0 || ~isfinite(p)
        error('FGKepler_trA:BadOrbit', ...
              'Computed p<=0/invalid. Check r0_vec, v0_vec, and mu.');
    end

    % ---- sigma0 term (lecture notation) ----
    sigma0 = dot(r0_vec, v0_vec) / sqrt(mu);

    cth = cos(dtheta);
    sth = sin(dtheta);

    % ---- Radius magnitude at new true anomaly (lecture formula) ----
    denom = r0 + (p - r0)*cth - sqrt(p)*sigma0*sth;

    if abs(denom) < 1e-12*max(r0,1)
        error('FGKepler_trA:DenomZero', ...
              'Denominator near zero; check inputs/Δθ.');
    end

    rf_mag = (p*r0) / denom;

    % ---- Lagrange coefficients (F,G) for Δθ form ----
    sqrt_mu_p = sqrt(mu*p);
    F = 1 - (rf_mag/p) * (1 - cth);
    G = (rf_mag*r0 / sqrt_mu_p) * sth;

    % ---- Propagate ----
    rf = F*r0_vec + G*v0_vec;

    % Optional debug outputs
    if nargout > 1
        out = struct();
        out.r0      = r0;
        out.h_vec   = h_vec;
        out.h       = h;
        out.p       = p;
        out.sigma0  = sigma0;
        out.rf_mag  = rf_mag;
        out.F       = F;
        out.G       = G;
        out.denom   = denom;
    end
end