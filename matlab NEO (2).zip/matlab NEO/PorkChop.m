clear all; close all; clc

%%

% Earth to Mars from 14/3/2016 to 15/10/2016
InTime=date2mjd2000([2016 03 14 0 0 0]);
FinTime=date2mjd2000([2016 10 15 0 0 0]);

% Generate grid of conditions to analyse
Range=3*30; % days
DepartureGrid=InTime-Range:5:InTime+Range;
ArrivalGrid=FinTime-Range:5:FinTime+Range;

muSun = getAstroConstants('Sun','mu');

Dv_solutions = zeros(length(DepartureGrid),length(ArrivalGrid));

for iD = 1:length(DepartureGrid)
    for iA = 1:length(ArrivalGrid)
        [r1, v1] = EphSS_car(3,DepartureGrid(iD));
        [r2, v2] = EphSS_car(4,ArrivalGrid(iA));
        Dt = (ArrivalGrid(iA)-DepartureGrid(iD))*24*3600;

        [r1_dot_short, r2_dot_short] = LambertArc_ATD2025(r1, r2, Dt, 1, muSun);
        [r1_dot_long, r2_dot_long] = LambertArc_ATD2025(r1, r2, Dt, -1, muSun);

        Dv_depart_short = norm(v1 - r1_dot_short);
        Dv_arrival_short = norm(v2 - r2_dot_short);
        Dv_depart_long = norm(v1 - r1_dot_long);
        Dv_arrival_long = norm(v2 - r2_dot_long);
        
        Dv_short = Dv_arrival_short + Dv_depart_short;
        Dv_long = Dv_arrival_long + Dv_depart_long;

        Dv_solutions(iD, iA) = min([Dv_short Dv_long]);
    end
end

minDv=min(min(Dv_solutions));

figure
contourf(DepartureGrid, ArrivalGrid, Dv_solutions', [minDv:0.1:8.5])
xlabel('Departure date [MJ2000]');
ylabel('Arrival date [MJ2000]');
colorbar;
cb = colorbar;
cb.Label.String = '\Delta V_{total} [km/s]';
cb.Label.FontSize = 15;




%% Functions

% Ex 2
    function r_final = FGKepler_trA(D_theta, r_0, r_dot_0, mu)
    h = cross(r_0, r_dot_0);
    p = norm(h)^2 / mu;
    sigma_0 = dot(r_0, r_dot_0)/sqrt(mu);
    r_f = (p*norm(r_0))/(norm(r_0) + (p - norm(r_0)) * cos(D_theta) - sqrt(p)*sigma_0*sin(D_theta));
    F = 1 - r_f/p * (1-cos(D_theta));
    G = r_f*norm(r_0)/(sqrt(mu*p)) * sin(D_theta);

    r_final = F*r_0 + G*r_dot_0;
    end

    function F = dynamics(t,x,mu)
    F = [x(4);
        x(5);
        x(6);
        -mu*x(1)/(sqrt(x(1)^2+x(2)^2+x(3)^2)^3);
        -mu*x(2)/(sqrt(x(1)^2+x(2)^2+x(3)^2)^3);
        -mu*x(3)/(sqrt(x(1)^2+x(2)^2+x(3)^2)^3)];
    end

    % Ex 3
    function r_f = FGKepler_dt(Dt, r_0, r_0_dot, mu)
    a = mu/(2*mu/norm(r_0) - norm(r_0_dot)^2);
    n = sqrt(mu/a^3);
    DM = n*Dt;
    sigma_0 = dot(r_0, r_0_dot)/sqrt(mu);
    fun = @(DE) DM - DE + (1 - norm(r_0)/a)*sin(DE) + sigma_0/sqrt(a)*(cos(DE)-1);
    DE = fzero(fun, DM);

    F = 1 - a/norm(r_0) * (1 - cos(DE));
    G = Dt + sqrt(a^3/mu)*(sin(DE)-DE);

    r_f = F*r_0 + G*r_0_dot;

    end

    % Ex 4

    function drf = STM_Lambert(Dt, r_0, r_0_dot, mu)
    a = mu/(2*mu/norm(r_0) - norm(r_0_dot)^2);
    n = sqrt(mu/a^3);
    DM = n*Dt;
    sigma_0 = dot(r_0, r_0_dot)/sqrt(mu);
    fun = @(DE) DM - DE + (1 - norm(r_0)/a)*sin(DE) + sigma_0/sqrt(a)*(cos(DE)-1);
    DE = fzero(fun, DM);

    F = 1 - a/norm(r_0) * (1 - cos(DE));
    G = Dt + sqrt(a^3/mu)*(sin(DE)-DE);
    r_f = F*r_0 + G*r_0_dot;

    F_dot = -sqrt(mu*a)/(norm(r_f)*norm(r_0))*sin(DE);
    G_dot = 1-a/norm(r_f)*(1-cos(DE));
    %r_f_dot = F_dot*r_0 + G_dot*r_0_dot;
    r_f_dot = 1/G*(-r_0+G_dot*r_f); 

    C = a*sqrt(a^3/mu)*(3*sin(DE)-(2+cos(DE))*DE)-a*Dt*(1-cos(DE));
    Dr = r_f - r_0;
    Dv = r_f_dot - r_0_dot;

    drf = norm(r_0)/mu*(1-F)*(Dr'*r_0_dot-Dv'*r_0)+C/mu*(r_f_dot'*r_0_dot) + G*eye(3);

    end

    % Ex 7

    function [a_min, e_min, Dt_min, r_0_dot] = MinETranfer(r_0,r_f,t_m,mu) % Ex 1 and 2 
    c = norm(r_0 - r_f);
    r_1 = norm(r_0);
    r_2 = norm(r_f);
    
    a_min = 1/4 * (r_1 + r_2 + c);
    
    c_theta = dot(r_0, r_f)/(r_1 * r_2);
    
    p = (r_1 * r_2)/c * (1 - c_theta);
    
    e_min = sqrt(1 - p/a_min);
    
    beta = 2 * asin(sqrt((2*a_min - c)/(2*a_min)));
    
    Dt_min = sqrt(a_min^3 / mu) * (pi - t_m * (beta - sin(beta)));

    s_theta = t_m * sqrt(1 - c_theta^2);

    F = 1 - r_2/p * (1 - c_theta);
    G = r_2*r_1/(sqrt(mu*p)) * s_theta;
    
    r_0_dot = 1 / G * (r_f - F * r_0);

    end

    function [r_0_dot, r_f_dot] = LambertArc_ATD2025(r_0, r_target, Dt_target, t_m, mu)
    [a_min, e_min, Dt_min, r_0_dot] = MinETranfer(r_0,r_target,t_m,mu);
    
    N = 10;
    for iT=1:N
        lbd = iT/N;
        Dt = lbd*Dt_target + (1-lbd)*Dt_min;

        ETolerance=1e-3;
        numMaxIter = 25;
        numIter = 0;
        r_f_iteration = 0;
        
        while (norm(r_f_iteration-r_target)>ETolerance)&&(numIter<numMaxIter)
            
            if numIter>numMaxIter
                numIter
                warning('numMaxIter issue: The shooting method did not converge')
                r_0_dot=[NaN NaN NaN];
                r_f_dot=[NaN NaN NaN];
            end
            
            r_f_iteration = FGKepler_dt(Dt, r_0, r_0_dot, mu);
            
            drf = STM_Lambert(Dt, r_0, r_0_dot, mu);

            Dr_cor = inv(drf) * (r_target  - r_f_iteration)';

            r_0_dot = r_0_dot + Dr_cor';

            % checks and warnings
            sma_seed = mu/2/ (mu/norm(r_0)-norm(r_0_dot)^2/2);
            if sma_seed<0
                sma_seed
                warning('sma_seed error: The shooting method did not converge ')
                r_0_dot=[NaN NaN NaN];
                r_f_dot=[NaN NaN NaN];
                return
            end
        end
    end
    r_f = FGKepler_dt(Dt_target, r_0, r_0_dot, mu);

    a = mu/(2*mu/norm(r_0) - norm(r_0_dot)^2);
    n = sqrt(mu/a^3);
    DM = n*Dt_target;
    sigma_0 = dot(r_0, r_0_dot)/sqrt(mu);
    fun = @(DE) DM - DE + (1 - norm(r_0)/a)*sin(DE) + sigma_0/sqrt(a)*(cos(DE)-1);
    DE = fzero(fun, DM);
    
    F = 1 - a/norm(r_0) * (1 - cos(DE));
    G = Dt + sqrt(a^3/mu)*(sin(DE)-DE);
    
    G_dot = 1 - a/norm(r_f) * (1-cos(DE));

    r_f_dot = 1/G * (-r_0+G_dot*r_f);
    end