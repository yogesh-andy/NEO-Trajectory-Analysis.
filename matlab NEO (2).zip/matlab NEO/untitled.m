%% ===================== Find Pau's trajectory =====================
dep_pau = date2mjd2000([2029 01 23 0 0 0]);
[~, iPau] = min(abs(Dep_Grid - dep_pau));
tof_pau = 328;
[~, jPau] = min(abs(TOF_Grid_days - tof_pau));

fprintf('\n================ PAU CROSS-CHECK ================\n');
fprintf('Dep: %s | TOF: %.0f d | Arr: %s\n', ...
    localDateStr(Dep_Grid(iPau)), TOF_Grid_days(jPau), ...
    localDateStr(Dep_Grid(iPau) + TOF_Grid_days(jPau)));
fprintf('V_inf_dep = %.3f km/s | C3 = %.2f km2/s2\n', ...
    vInfE_best(iPau,jPau), vInfE_best(iPau,jPau)^2);
fprintf('V_inf_arr = %.3f km/s\n', vInfN_best(iPau,jPau));
fprintf('Delivered mass = %.1f kg\n', FinalMassMatrix(iPau,jPau));
fprintf('Branch = %s\n', branchStr(tm_best(iPau,jPau)));
fprintf('=================================================\n');